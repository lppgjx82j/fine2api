// sim2openai.mjs v2.1 — Sim.ai 工作流 -> OpenAI 兼容反代（真流式 + 管理面板 + 热重载 + 速度监控 + 多账号轮询/验活）
// Node 18+，零依赖。启动：双击 start.bat，或 node sim2openai.mjs
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const VERSION    = '2.1.0';
const DIR        = path.dirname(fileURLToPath(import.meta.url));
const ENV_FILE   = path.join(DIR, '.env');
const PUBLIC_DIR = path.join(DIR, 'public');
const STARTED    = Date.now();

// ===================== 配置：.env（文件优先，其次系统环境变量），改动自动热重载 =====================
function parseEnv(text) {
  const out = {};
  for (const raw of String(text).replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 0) continue;
    const k = line.slice(0, eq).trim().replace(/^export\s+/, '').toUpperCase();
    let v = line.slice(eq + 1).trim();
    if (v.length >= 2 && ((v[0] === '"' && v.at(-1) === '"') || (v[0] === "'" && v.at(-1) === "'"))) v = v.slice(1, -1);
    out[k] = v;
  }
  return out;
}
function readEnvFile() { try { return parseEnv(fs.readFileSync(ENV_FILE, 'utf8')); } catch { return {}; } }

let C = {};
function loadConfig() {
  const f = readEnvFile();
  const g = (k, d = '') => String(f[k] ?? process.env[k] ?? d);
  let models = {};
  try { models = JSON.parse(g('MODELS', '{}') || '{}'); } catch { console.warn('[配置] MODELS 不是合法 JSON，已忽略'); }
  C = {
    PORT: Number(g('PORT', 8787)),
    HOST: g('HOST', '0.0.0.0'),
    SIM_BASE: g('SIM_BASE', 'https://www.sim.ai').replace(/\/+$/, ''),
    SIM_API_KEY: g('SIM_API_KEY'),
    PROXY_KEY: g('PROXY_KEY'),
    WORKFLOW_ID: g('WORKFLOW_ID'),
    MODELS: models,
    INPUT_FIELD: g('INPUT_FIELD', 'message'),
    SELECTED_OUTPUT: g('SELECTED_OUTPUT', 'agent.content'),
    HISTORY_MODE: g('HISTORY_MODE', 'full'),
    INCLUDE_THINKING: g('INCLUDE_THINKING', '0') === '1',
    PING_MS: Number(g('PING_MS', 15000)),
    DEBUG: Number(g('DEBUG', '1')) || 0,                       // 0 关 / 1 速度 / 2 速度+原始帧 / 3 速度+保存提示词
    STRIP_ABSOLUTE_ZERO: g('STRIP_ABSOLUTE_ZERO', '1') === '1', // 自动删掉会触发降级的 Absolute zero 指令
    FETCH_RUN_STATS: g('FETCH_RUN_STATS', '1') === '1',         // 每次调用后回查 Sim 记录的真实 token / 费用
    FAST_TPS_WARN: Number(g('FAST_TPS_WARN', 140)),             // 出字速度超过这个值标记为“疑似降级”
    PROMPT_LOG_FILE: g('PROMPT_LOG_FILE', 'prompts.txt'),
    // ---- 多账号 ----
    ROTATE_MODE: g('ROTATE_MODE', 'priority') === 'round' ? 'round' : 'priority', // priority 优先模式 / round 分散轮询
    FAILOVER: g('FAILOVER', '1') === '1',                       // 账号出错时自动换下一个重试
    MAX_SWITCH: Math.max(0, Number(g('MAX_SWITCH', 3)) || 0),   // 单个请求最多换几次号
    EXHAUST_MARGIN: Math.max(0, Number(g('EXHAUST_MARGIN', 0.5)) || 0), // 剩余额度低于此美元数视为用完
    AUTO_CHECK_MIN: Math.max(0, Number(g('AUTO_CHECK_MIN', 30)) || 0),  // 定时验活间隔（分钟），0 关闭
    COOLDOWN_RATE: Number(g('COOLDOWN_RATE', 60)) || 60,        // 429 限流冷却秒数
    COOLDOWN_ERR: Number(g('COOLDOWN_ERR', 30)) || 30,          // 5xx / 网络错误冷却秒数
  };
  C.PROMPT_LOG = path.join(DIR, C.PROMPT_LOG_FILE);
  setupAutoCheck();
}
loadConfig();

const EDITABLE = ['SIM_BASE', 'SIM_API_KEY', 'PROXY_KEY', 'WORKFLOW_ID', 'MODELS', 'INPUT_FIELD', 'SELECTED_OUTPUT',
  'HISTORY_MODE', 'INCLUDE_THINKING', 'PING_MS', 'DEBUG', 'STRIP_ABSOLUTE_ZERO', 'FETCH_RUN_STATS', 'FAST_TPS_WARN', 'PROMPT_LOG_FILE',
  'ROTATE_MODE', 'FAILOVER', 'MAX_SWITCH', 'EXHAUST_MARGIN', 'AUTO_CHECK_MIN', 'COOLDOWN_RATE', 'COOLDOWN_ERR'];

function writeEnv(updates) {
  let text = '';
  try { text = fs.readFileSync(ENV_FILE, 'utf8').replace(/^\uFEFF/, ''); } catch {}
  const lines = text ? text.split(/\r?\n/) : [];
  const done = new Set();
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=/);
    if (!m) continue;
    const k = m[1].toUpperCase();
    if (!(k in updates)) continue;
    if (done.has(k)) { lines[i] = '# (重复项已注释) ' + lines[i]; continue; }
    lines[i] = `${k}=${updates[k]}`;
    done.add(k);
  }
  for (const [k, v] of Object.entries(updates)) if (!done.has(k)) lines.push(`${k}=${v}`);
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  fs.writeFileSync(ENV_FILE, lines.join('\r\n') + '\r\n', 'utf8');
  loadConfig();
}
let lastMtime = 0;
fs.watchFile(ENV_FILE, { interval: 1500 }, cur => {
  if (cur.mtimeMs && cur.mtimeMs !== lastMtime) {
    lastMtime = cur.mtimeMs;
    const oldKey = C.SIM_API_KEY;
    loadConfig();
    console.log('[配置] .env 已变更，已热重载（PORT/HOST 需重启才生效）');
    // 手动在 .env 里换了 SIM_API_KEY：自动加进账号池
    if (C.SIM_API_KEY && C.SIM_API_KEY !== oldKey && !ACCS.some(a => a.key === C.SIM_API_KEY)) {
      const { acc } = upsertAccount({ key: C.SIM_API_KEY, workflowId: C.WORKFLOW_ID });
      console.log(`[账号] .env 里的新 SIM_API_KEY 已加入账号池：${acc.name}`);
      checkAccount(acc);
    }
  }
});

// ===================== 通用工具 =====================
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Admin-Key, X-Requested-With, *',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};
const sleep = ms => new Promise(r => setTimeout(r, ms));
function json(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...CORS });
  res.end(JSON.stringify(obj));
}
function oaiError(res, status, message, type = 'proxy_error') { json(res, status, { error: { message, type, code: status } }); }
function readBody(req, limit = 50 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new Error('body too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function textOf(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.filter(p => p && p.type === 'text').map(p => p.text).join('\n');
  return content == null ? '' : String(content);
}
function errText(e) {
  if (e == null) return '';
  if (typeof e === 'string') return e;
  return e.message || e.code || JSON.stringify(e);
}
const mask = k => (k ? k.slice(0, 8) + '…' + k.slice(-4) : '');
const ROLE = { system: 'System', user: 'User', assistant: 'Assistant', tool: 'Tool', developer: 'System' };
function buildPrompt(messages) {
  if (!Array.isArray(messages) || !messages.length) return '';
  if (C.HISTORY_MODE === 'last') {
    for (let i = messages.length - 1; i >= 0; i--) if (messages[i].role === 'user') return textOf(messages[i].content);
    return textOf(messages.at(-1).content);
  }
  if (messages.length === 1 && messages[0].role === 'user') return textOf(messages[0].content);
  return messages.map(m => `${ROLE[m.role] || m.role}: ${textOf(m.content)}`).join('\n\n') + '\n\nAssistant:';
}
function resolveWorkflow(model) {
  if (model && C.MODELS[model]) return C.MODELS[model];
  if (C.WORKFLOW_ID) return C.WORKFLOW_ID;
  return /^[0-9a-f-]{36}$/i.test(model || '') ? model : '';
}
function modelIds() { const ids = Object.keys(C.MODELS); return ids.length ? ids : ['sim']; }
function outputToText(out) {
  if (out == null) return '';
  if (typeof out === 'string') return out;
  if (typeof out.content === 'string') return out.content;
  if (typeof out.result === 'string') return out.result;
  if (out[C.SELECTED_OUTPUT] != null) return outputToText(out[C.SELECTED_OUTPUT]);
  const blk = out[C.SELECTED_OUTPUT.split('.')[0]];
  if (blk && typeof blk.content === 'string') return blk.content;
  return JSON.stringify(out);
}
function extractUsage(out) {
  const t = out && (out.tokens || out.usage);
  if (!t) return null;
  const p = t.prompt ?? t.input ?? t.prompt_tokens ?? 0;
  const c = t.completion ?? t.output ?? t.completion_tokens ?? 0;
  return { prompt_tokens: p, completion_tokens: c, total_tokens: t.total ?? t.total_tokens ?? p + c };
}
function estTokens(s) { // 粗估：中日韩字符≈1 token/字，其余≈4 字符/token
  if (!s) return 0;
  const cjk = (s.match(/[\u3000-\u9fff\uac00-\ud7af\uff00-\uffef]/g) || []).length;
  return Math.round(cjk + (s.length - cjk) / 4);
}
function lanUrls() {
  const out = [];
  for (const arr of Object.values(os.networkInterfaces())) for (const a of arr || [])
    if (a.family === 'IPv4' && !a.internal) out.push(`http://${a.address}:${C.PORT}/v1`);
  return out;
}
function deepFind(obj, pred, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 10) return null;
  try { if (pred(obj)) return obj; } catch {}
  for (const v of Object.values(obj)) { const r = deepFind(v, pred, depth + 1); if (r) return r; }
  return null;
}

// ===================== 请求日志 & 统计（面板用） =====================
const LOGS = []; let SEQ = 0;
const STATS = { total: 0, ok: 0, err: 0, tpsSum: 0, tpsN: 0, cost: 0 };
function newEntry(o) {
  const e = { id: ++SEQ, time: Date.now(), status: 'running', ...o };
  LOGS.push(e); if (LOGS.length > 300) LOGS.shift();
  STATS.total++;
  return e;
}
function finalize(e, st, err) {
  const now = Date.now();
  e.total = now - st.t0;
  e.upMs = st.tUp ? st.tUp - st.t0 : null;
  e.firstMs = st.tFirst ? st.tFirst - st.t0 : null;
  e.thinkMs = st.tThink ? st.tThink - st.t0 : null;
  e.chars = [...st.text].length;
  e.estTok = estTokens(st.text);
  e.thinkChars = [...st.think].length;
  if (st.tFirst) {
    const gen = Math.max(now - st.tFirst, 1) / 1000;
    e.genMs = Math.round(gen * 1000);
    e.cps = +(e.chars / gen).toFixed(1);
    e.tps = +(e.estTok / gen).toFixed(1);
  }
  e.status = err ? 'error' : 'ok';
  e.err = err || null;
  e.suspect = !!(e.tps && e.tps >= C.FAST_TPS_WARN);
  if (err) STATS.err++; else { STATS.ok++; if (e.tps) { STATS.tpsSum += e.tps; STATS.tpsN++; } }
  if (C.DEBUG >= 1) console.log(report(e));
}
function report(e) {
  const s = ms => (ms == null ? '-' : (ms / 1000).toFixed(1) + 's');
  let head = `[速度] #${e.id} ${e.model} | 账号 ${e.account || '-'} | ${e.stream ? '流式' : '非流式'} | 输入 ${e.promptChars} 字 | 总耗时 ${s(e.total)}`;
  if (e.upMs != null) head += ` | 上游响应 ${s(e.upMs)}`;
  if (e.thinkMs != null) head += ` | 开始思考 ${s(e.thinkMs)}`;
  if (e.firstMs != null) head += ` | 首字 ${s(e.firstMs)}`;
  const lines = [head];
  if (e.tps) lines.push(`       正文 ${e.chars} 字 ≈ ${e.estTok} tok | 生成 ${s(e.genMs)} | 出字速度 ${e.cps} 字/s ≈ ${e.tps} tok/s（首字之后）`);
  else if (e.chars) lines.push(`       正文 ${e.chars} 字 ≈ ${e.estTok} tok（上游整包返回，测不了出字速度）`);
  if (e.thinkChars) lines.push(`       思考 ${e.thinkChars} 字（已流出）`);
  if (e.switches) lines.push(`       ↪ 换号 ${e.switches} 次：${(e.failover || []).join(' → ')}`);
  if (e.suspect) lines.push(`       ⚠ 出字速度 ≥ ${C.FAST_TPS_WARN} tok/s，明显快于正常 Argon（约 30～70），疑似被降级路由`);
  if (e.az) lines.push(e.az === 'stripped' ? '       ℹ 已自动删除提示词里的 Absolute zero 指令' : '       ⚠ 提示词含 Absolute zero 指令（已知会触发降级），建议 STRIP_ABSOLUTE_ZERO=1');
  if (e.err) lines.push(`       ✗ ${e.err}`);
  return lines.join('\n');
}

// 调用结束后用 x-run-id 回查 Sim 自己记录的真实 token / 费用 / 模型（流式模式下 final 帧拿不到这些）
async function fetchRunStats(e, acc) {
  if (!C.FETCH_RUN_STATS || !e.runId || !acc) return;
  const simKey = acc.key;
  for (let attempt = 0; attempt < 3; attempt++) {
    await sleep(1000 + attempt * 1500);
    try {
      const r = await fetch(`${C.SIM_BASE}/api/v2/workflows/${encodeURIComponent(e.workflowId)}/runs/${encodeURIComponent(e.runId)}?includeOutput=true`,
        { headers: { 'X-API-Key': simKey } });
      if (!r.ok) { e.runStatsErr = 'HTTP ' + r.status; if (r.status === 404 && attempt < 2) continue; return; }
      const d = await r.json();
      const tok = deepFind(d, o => o.tokens && typeof o.tokens === 'object' && (o.tokens.output != null || o.tokens.completion != null))?.tokens;
      if (!tok && attempt < 2) continue;
      const cost = deepFind(d, o => o.cost && typeof o.cost === 'object' && typeof o.cost.total === 'number')?.cost;
      const pt = deepFind(d, o => o.providerTiming && typeof o.providerTiming === 'object')?.providerTiming;
      const seg = pt?.timeSegments?.[0];
      const mdl = seg?.name || deepFind(d, o => typeof o.model === 'string')?.model;
      if (tok) e.usage = { input: tok.input ?? tok.prompt ?? 0, output: tok.output ?? tok.completion ?? 0, cached: tok.cacheRead ?? 0, reasoning: seg?.tokens?.reasoning ?? 0 };
      if (cost) {
        e.cost = cost.total; STATS.cost += cost.total;
        acc.st.spent = (acc.st.spent || 0) + cost.total;
        if (acc.st.usage) acc.st.usage.cost += cost.total;   // 本地累加，下次验活时会被 Sim 的真实数字覆盖
        saveAccounts();
      }
      if (mdl) e.upModel = mdl;
      if (seg?.provider) e.provider = seg.provider;
      if (pt?.modelTime) e.modelMs = pt.modelTime;
      if (e.usage?.output && e.modelMs) e.realTps = +(e.usage.output / (e.modelMs / 1000)).toFixed(1);
      if (e.realTps >= C.FAST_TPS_WARN) e.suspect = true;
      if (C.DEBUG >= 1 && e.usage) {
        console.log(`       [#${e.id} Sim 记录] ${e.upModel || '?'}${e.provider ? ' / ' + e.provider : ''} | 输入 ${e.usage.input} tok（缓存 ${e.usage.cached}）| 输出 ${e.usage.output} tok（思考 ${e.usage.reasoning}）| 费用 $${(e.cost ?? 0).toFixed(4)} | 模型耗时 ${((e.modelMs || 0) / 1000).toFixed(1)}s → ${e.realTps ?? '-'} tok/s${e.realTps >= C.FAST_TPS_WARN ? '  ⚠ 疑似降级' : ''}`);
      }
      return;
    } catch (err) { e.runStatsErr = err.message; }
  }
}

function savePrompt(e, prompt, payload) {
  const sep = '='.repeat(60);
  const head = `${sep}\n[${new Date().toLocaleString('zh-CN', { hour12: false })}] #${e.id} model=${e.model} stream=${!!payload.stream}\n消息数 ${e.msgCount} | 发给 Sim 的提示词 ${e.promptChars} 字 | HISTORY_MODE=${C.HISTORY_MODE}\n${sep}\n`;
  fs.appendFile(C.PROMPT_LOG, head + prompt + '\n\n', 'utf8', err => {
    if (err) console.error('[提示词] 写入失败:', err.message);
    else console.log(`[提示词] 已保存 ${e.promptChars} 字 -> ${C.PROMPT_LOG}`);
  });
}

// ===================== Sim 上游 =====================
async function* simFrames(body) {
  const dec = new TextDecoder(); let buf = '';
  for await (const chunk of body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const raw = line.slice(5).trim(); if (!raw) continue;
      if (raw === '[DONE]') return;
      let f; try { f = JSON.parse(raw); } catch { continue; }
      if (C.DEBUG === 2) console.log('[sim frame]', raw.slice(0, 300));
      if (f === '[DONE]') return;
      if (f && typeof f === 'object') yield f;
    }
  }
}
function callSim(simKey, workflowId, prompt, signal) {
  const body = { input: { [C.INPUT_FIELD]: prompt }, stream: true, selectedOutputs: [C.SELECTED_OUTPUT] };
  if (C.INCLUDE_THINKING) body.includeThinking = true;
  const url = `${C.SIM_BASE}/api/v2/workflows/${encodeURIComponent(workflowId)}/execute`;
  if (C.DEBUG === 2) console.log('[sim req]', url, prompt.length, '字');
  return fetch(url, {
    method: 'POST', signal,
    headers: { 'X-API-Key': simKey, 'Content-Type': 'application/json', 'Accept': 'text/event-stream', 'X-Sim-Stream-Protocol': 'agent-events-v1' },
    body: JSON.stringify(body),
  });
}

// ===================== 多账号池：轮询 / 故障切换 / 批量验活 =====================
// 账号保存在 accounts.json：每个账号 = Sim API Key + 这个账号自己的工作流 ID（不同 Sim 账号互相访问不了对方的工作流）
const ACC_FILE = path.join(DIR, 'accounts.json');
let ACCS = [];
let RR = 0;                 // 分散轮询指针
var autoTimer = null;       // 用 var：loadConfig() 在这之前就会调用 setupAutoCheck()
const STATUS_CN = { unknown: '未验证', ok: '正常', exhausted: '额度用完', invalid: 'Key 无效', bad_wf: '工作流不可用', cooldown: '冷却中', error: '异常' };
const ST0 = () => ({ status: 'unknown', msg: '', checkedAt: 0, cooldownUntil: 0, usage: null, rate: null, reqs: 0, ok: 0, fail: 0, spent: 0, lastUsed: 0, checking: false });
const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

function mkAcc(o) {
  return { id: randomUUID().slice(0, 8), name: String(o.name || '').trim(), key: String(o.key).trim(), workflowId: String(o.workflowId || '').trim(), enabled: o.enabled !== false, st: ST0() };
}
let accMtime = 0;
function loadAccounts() {
  try {
    const d = JSON.parse(fs.readFileSync(ACC_FILE, 'utf8').replace(/^\uFEFF/, ''));
    const list = Array.isArray(d) ? d : d.accounts || [];
    ACCS = list.filter(a => a && a.key).map(a => ({ ...mkAcc(a), id: a.id || randomUUID().slice(0, 8), st: { ...ST0(), ...(a.st || {}), checking: false } }));
    accMtime = fs.statSync(ACC_FILE).mtimeMs;
  } catch (err) {
    if (err.code !== 'ENOENT') console.warn('[账号] accounts.json 读取失败（格式不对？）：' + err.message);
  }
  ACCS.forEach((a, i) => { if (!a.name) a.name = '账号' + (i + 1); });
}
let saveTimer = null;
function saveAccounts(now = false) {
  const write = () => {
    saveTimer = null;
    const data = { version: 1, accounts: ACCS.map(({ st, ...a }) => ({ ...a, st: { ...st, checking: undefined } })) };
    try { fs.writeFileSync(ACC_FILE, JSON.stringify(data, null, 2), 'utf8'); accMtime = fs.statSync(ACC_FILE).mtimeMs; }
    catch (err) { console.error('[账号] accounts.json 保存失败：' + err.message); }
  };
  if (now) { clearTimeout(saveTimer); return write(); }
  if (!saveTimer) saveTimer = setTimeout(write, 1200);
}
// 手动编辑 accounts.json 也会自动重载
fs.watchFile(ACC_FILE, { interval: 2000 }, cur => {
  if (cur.mtimeMs && Math.abs(cur.mtimeMs - accMtime) > 5) { loadAccounts(); console.log(`[账号] accounts.json 已变更，重新载入 ${ACCS.length} 个账号`); }
});

function upsertAccount(o) {
  const ex = ACCS.find(a => a.key === o.key);
  if (ex) {
    if (o.workflowId) ex.workflowId = o.workflowId;
    if (o.name) ex.name = o.name;
    ex.enabled = true;
    ex.st = { ...ST0(), reqs: ex.st.reqs, ok: ex.st.ok, fail: ex.st.fail, spent: ex.st.spent };
    saveAccounts(true);
    return { acc: ex, added: false };
  }
  const a = mkAcc(o);
  if (!a.name) a.name = '账号' + (ACCS.length + 1);
  ACCS.push(a);
  saveAccounts(true);
  return { acc: a, added: true };
}
// 批量导入：每行一个，Key 必填，工作流 ID / 名称可选、顺序随意，分隔符随意（空格 , ; | ---- 制表符）
function parseImport(text) {
  const out = [];
  for (const raw of String(text || '').split(/\r?\n/)) {
    let line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const wf = line.match(UUID_RE)?.[0] || '';
    if (wf) line = line.replace(wf, ' ');
    let key = line.match(/sk-sim-[A-Za-z0-9_-]{32}(?![A-Za-z0-9_])/)?.[0] || line.match(/sk-sim-[A-Za-z0-9_-]+/)?.[0]?.replace(/-+$/, '');
    if (!key) continue;
    const name = line.replace(key, ' ').replace(/-{2,}|[,，;；|\t]/g, ' ').replace(/\s+/g, ' ').trim();
    out.push({ key, workflowId: wf, name });
  }
  return out;
}

function accWf(a, model) { return a.workflowId || resolveWorkflow(model); }
function unusableReason(a, model = '', now = Date.now()) {
  if (!a.enabled) return '已停用';
  if (!accWf(a, model)) return '没有工作流 ID';
  if (['exhausted', 'invalid', 'bad_wf'].includes(a.st.status)) return STATUS_CN[a.st.status];
  if (a.st.cooldownUntil > now) return `冷却中 ${Math.ceil((a.st.cooldownUntil - now) / 1000)}s`;
  const u = a.st.usage;
  if (u && u.limit != null && u.limit - u.cost < C.EXHAUST_MARGIN) return `剩余额度 < $${C.EXHAUST_MARGIN}`;
  return '';
}
// ① priority 优先模式：永远从排在最前面、还能用的账号开始，用完/出错才顺延到下一个
// ② round 分散轮询：每个请求换下一个可用账号，费用平摊
function pickAccount(model, tried, pool = ACCS, peek = false) {
  const now = Date.now();
  const ok = a => !tried.has(a.id) && !unusableReason(a, model, now);
  if (pool !== ACCS || C.ROTATE_MODE !== 'round') return pool.find(ok) || null;
  const n = ACCS.length;
  for (let i = 0; i < n; i++) {
    const idx = (RR + i) % n;
    if (ok(ACCS[idx])) { if (!peek) RR = (idx + 1) % n; return ACCS[idx]; }
  }
  return null;
}
function classify(status, msg = '') {
  if (status === 429 || /rate.?limit|too many requests/i.test(msg)) return 'rate';
  if (status === 402 || /usage limit|limit exceeded|insufficient (credit|fund|balance)|quota|billing/i.test(msg)) return 'exhausted';
  if (status === 401 || status === 403) return 'invalid';
  if (status === 404) return 'bad_wf';
  if (status === 400 || status === 413 || status === 422) return 'request';   // 请求本身有问题，换号也没用
  return 'error';
}
function markResult(a, kind, msg = '', retryAfterSec = 0) {
  if (!a || a.temp) return;
  if (kind === 'ok') {
    a.st.ok++; a.st.status = 'ok'; a.st.cooldownUntil = 0;
  } else {
    a.st.fail++; a.st.msg = String(msg).slice(0, 300);
    if (['exhausted', 'invalid', 'bad_wf'].includes(kind)) a.st.status = kind;
    else if (kind === 'rate' || kind === 'error') {
      a.st.status = 'cooldown';
      a.st.cooldownUntil = Date.now() + 1000 * (retryAfterSec || (kind === 'rate' ? C.COOLDOWN_RATE : C.COOLDOWN_ERR));
    }
  }
  saveAccounts();
}

// ---------- 验活 ----------
async function simGet(a, p) {
  const r = await fetch(C.SIM_BASE + p, { headers: { 'X-API-Key': a.key }, signal: AbortSignal.timeout(15000) });
  const t = await r.text().catch(() => '');
  let d = null; try { d = JSON.parse(t); } catch {}
  return { status: r.status, ok: r.ok, d, t };
}
// 快速验活（免费）：查额度 /api/users/me/usage-limits + 工作流部署状态 /api/workflows/{id}/status
// 深度验活：再真实调用一次工作流（花一点点钱），确认真的能出字
async function checkAccount(a, deep = false) {
  if (a.st.checking) return a;
  a.st.checking = true;
  let status = 'ok';
  const msg = [];
  const wf = a.workflowId || C.WORKFLOW_ID;
  try {
    const [u, w] = await Promise.all([
      simGet(a, '/api/users/me/usage-limits').catch(err => ({ status: 0, err })),
      wf ? simGet(a, `/api/workflows/${encodeURIComponent(wf)}/status`).catch(err => ({ status: 0, err })) : null,
    ]);
    const uAuthBad = u.status === 401 || u.status === 403;
    const wAuthBad = w && (w.status === 401 || w.status === 403);
    // 1) Key
    if (uAuthBad && (!w || wAuthBad)) { status = 'invalid'; msg.push('Key 无效或已删除：' + (errText(u.d?.error) || 'HTTP ' + u.status)); }
    // 2) 额度
    if (u.ok && u.d) {
      const us = u.d.usage || {};
      const cost = Number(us.currentPeriodCost ?? us.current ?? 0);
      const limit = us.limit != null ? Number(us.limit) : null;
      a.st.usage = { cost, limit, plan: us.plan || '', at: Date.now() };
      const rs = u.d.rateLimit?.sync;
      a.st.rate = rs ? { remaining: rs.remaining, limited: !!rs.isLimited, resetAt: rs.resetAt } : null;
      if (limit != null && limit - cost < C.EXHAUST_MARGIN) { if (status === 'ok') status = 'exhausted'; msg.push(`额度用完 $${cost.toFixed(2)} / $${limit.toFixed(2)}`); }
      else msg.push(`额度 $${cost.toFixed(2)} / ${limit != null ? '$' + limit.toFixed(2) : '不限'}${us.plan ? '（' + us.plan + '）' : ''}`);
    } else if (!uAuthBad) msg.push('额度查询失败 ' + (u.err ? (u.err.cause?.code || u.err.message) : 'HTTP ' + u.status));
    // 3) 工作流
    if (status === 'ok') {
      if (!wf) { status = 'bad_wf'; msg.push('没有工作流 ID'); }
      else if (w.ok) {
        if (w.d && w.d.isDeployed === false) { status = 'bad_wf'; msg.push('工作流未部署'); }
        else msg.push('工作流已部署' + (w.d?.needsRedeployment ? '（有改动还没重新部署）' : ''));
      } else if (w.status === 404 || wAuthBad) { status = 'bad_wf'; msg.push(`工作流不可访问 HTTP ${w.status}（ID 不对，或不属于这个 Key 的账号）`); }
      else if (w.status === 0 && u.status === 0) { status = 'error'; msg.push('连不上 Sim：' + (w.err?.cause?.code || w.err?.message)); }
      else msg.push('工作流状态查询失败 HTTP ' + w.status);
    }
    // 4) 深度：真实调用一次
    if (deep && status === 'ok') {
      const t0 = Date.now();
      const r = await callSim(a.key, wf, 'Reply with exactly one word: OK', AbortSignal.timeout(120000));
      if (!r.ok || !r.body) {
        const t = await r.text().catch(() => '');
        let m = t; try { m = errText(JSON.parse(t).error) || t; } catch {}
        const k = classify(r.status, m);
        status = ['exhausted', 'invalid', 'bad_wf'].includes(k) ? k : 'error';
        msg.push(`实调失败 HTTP ${r.status}：${String(m).slice(0, 160)}`);
      } else {
        let text = '', err = null;
        for await (const f of simFrames(r.body)) {
          if (f.event === undefined && typeof f.chunk === 'string') text += f.chunk;
          else if (f.event === 'final') { if (f.data?.success === false) err = errText(f.data.error) || 'workflow failed'; else if (!text) { const t = outputToText(f.data?.output); if (t !== '{}') text = t; } break; }
          else if (f.event === 'error') { err = errText(f.error) || 'stream error'; break; }
        }
        if (err) { status = classify(0, err) === 'exhausted' ? 'exhausted' : 'error'; msg.push('实调出错：' + err.slice(0, 160)); }
        else if (!text.trim()) { status = 'error'; msg.push(`实调没有输出（检查 SELECTED_OUTPUT=${C.SELECTED_OUTPUT}）`); }
        else msg.push(`实调成功 ${((Date.now() - t0) / 1000).toFixed(1)}s「${text.trim().slice(0, 16)}」`);
      }
    }
  } catch (err) {
    status = 'error'; msg.push('验活出错：' + (err.cause?.code || err.message));
  }
  a.st.checking = false;
  a.st.status = status;
  a.st.msg = msg.join('；');
  a.st.checkedAt = Date.now();
  if (status === 'ok') a.st.cooldownUntil = 0;
  saveAccounts();
  return a;
}
async function checkMany(list, deep = false, conc = 4) {
  const q = [...list];
  await Promise.all(Array.from({ length: Math.min(conc, q.length) }, async () => { while (q.length) await checkAccount(q.shift(), deep); }));
  const cnt = {};
  for (const a of list) cnt[a.st.status] = (cnt[a.st.status] || 0) + 1;
  if (list.length) console.log(`[验活] ${deep ? '深度' : '快速'}验活 ${list.length} 个账号：` + Object.entries(cnt).map(([k, v]) => `${STATUS_CN[k] || k} ${v}`).join('，'));
  return cnt;
}
function setupAutoCheck() {
  clearInterval(autoTimer);
  autoTimer = null;
  if (C.AUTO_CHECK_MIN > 0) autoTimer = setInterval(() => checkMany(ACCS.filter(a => a.enabled)).catch(() => {}), C.AUTO_CHECK_MIN * 60000);
}

loadAccounts();
if (!ACCS.length && C.SIM_API_KEY) {   // 从 v2.0 升级：把 .env 里的单个 key 搬进账号池
  ACCS.push({ ...mkAcc({ key: C.SIM_API_KEY, workflowId: C.WORKFLOW_ID }), name: '账号1' });
  saveAccounts(true);
  console.log('[账号] 已把 .env 里的 SIM_API_KEY 导入账号池（accounts.json）');
}

// ===================== /v1/chat/completions =====================
const AZ_RE = /\[Absolute zero system prompt:[^\]]*\]\s*/gi;

async function chatCompletions(req, res, passKey) {
  let payload;
  try { payload = JSON.parse(await readBody(req)); } catch { return oaiError(res, 400, 'invalid JSON body'); }
  const model = payload.model || modelIds()[0];
  // 没设 PROXY_KEY 且客户端直接填了 Sim key：只用这个 key（透传），不走账号池
  const pool = passKey ? [{ ...mkAcc({ key: passKey, name: '透传' }), temp: true }] : ACCS;
  if (!pool.length) return oaiError(res, 401, '账号池是空的：打开管理面板添加 Sim 账号，或在 sim.ai 页面用浏览器扩展一键配置');

  let prompt = buildPrompt(payload.messages);
  const azFound = AZ_RE.test(prompt); AZ_RE.lastIndex = 0;
  if (azFound && C.STRIP_ABSOLUTE_ZERO) prompt = prompt.replace(AZ_RE, '');

  const e = newEntry({
    model, workflowId: '', account: '', stream: !!payload.stream,
    msgCount: Array.isArray(payload.messages) ? payload.messages.length : 0,
    promptChars: [...prompt].length,
    az: azFound ? (C.STRIP_ABSOLUTE_ZERO ? 'stripped' : 'kept') : null,
    client: (req.socket?.remoteAddress || '').replace(/^::ffff:/, ''),
  });
  if (C.DEBUG >= 3) savePrompt(e, prompt, payload);

  const st = { t0: Date.now(), text: '', think: '', tFirst: 0, tThink: 0, tUp: 0 };
  const ac = new AbortController();
  res.on('close', () => { if (!res.writableEnded) ac.abort(); });

  // ---------- 选账号 + 失败自动换号（只在还没给客户端发任何字节时换，所以对酒馆完全无感） ----------
  const tried = new Set(), fails = [];
  const canSwitch = () => C.FAILOVER && !passKey && fails.length <= C.MAX_SWITCH;
  let up, acc, workflowId, lastStatus = 502;
  for (;;) {
    acc = pickAccount(model, tried, pool);
    if (!acc) {
      const why = fails.length ? fails.join(' → ') : pool.map(a => `[${a.name}] ${unusableReason(a, model) || '可用'}`).join('；');
      const m = '没有可用的 Sim 账号：' + why;
      finalize(e, st, m);
      return oaiError(res, fails.length ? lastStatus : 503, m, 'upstream_error');
    }
    tried.add(acc.id);
    workflowId = accWf(acc, model);
    e.account = acc.name; e.workflowId = workflowId;
    if (!acc.temp) { acc.st.reqs++; acc.st.lastUsed = Date.now(); }
    try { up = await callSim(acc.key, workflowId, prompt, ac.signal); }
    catch (err) {
      if (ac.signal.aborted) { finalize(e, st, '客户端中途断开'); return; }
      const m = '连接 Sim 失败: ' + err.message + (err.cause ? ` (${err.cause.code || err.cause.message})` : '');
      markResult(acc, 'error', m);
      fails.push(`[${acc.name}] ${m}`); lastStatus = 502;
      if (canSwitch()) { console.log(`[轮询] ${acc.name} 连接失败 → 换下一个账号`); continue; }
      finalize(e, st, fails.join(' → '));
      return oaiError(res, 502, m);
    }
    if (up.ok && up.body) break;

    const t = await up.text().catch(() => '');
    let msg = t; try { msg = errText(JSON.parse(t).error) || t; } catch {}
    const kind = classify(up.status, String(msg));
    if (kind === 'exhausted') msg += '（额度用完：sim.ai → Settings → Subscription）';
    else if (kind === 'bad_wf') msg += '（工作流 ID 不对 / 没部署 / 这个 key 访问不了该工作流）';
    else if (kind === 'invalid') msg += '（Sim API key 无效或没有该工作区权限）';
    else if (up.status === 400) msg += `（常见原因：INPUT_FIELD=${C.INPUT_FIELD} 或 SELECTED_OUTPUT=${C.SELECTED_OUTPUT} 与工作流不匹配）`;
    if (kind !== 'request') markResult(acc, kind, `HTTP ${up.status}: ${msg}`, Number(up.headers.get('retry-after')) || 0);
    fails.push(`[${acc.name}] HTTP ${up.status}: ${String(msg).slice(0, 200)}`); lastStatus = up.status || 502;
    if (kind !== 'request' && canSwitch()) { console.log(`[轮询] ${acc.name} ${STATUS_CN[kind] || 'HTTP ' + up.status} → 换下一个账号`); continue; }
    finalize(e, st, fails.join(' → '));
    return oaiError(res, up.status || 502, `sim upstream ${up.status}: ${msg}`, 'upstream_error');
  }
  if (fails.length) { e.switches = fails.length; e.failover = fails; }
  st.tUp = Date.now();
  e.runId = up.headers.get('x-run-id') || null;
  // 流里的报错（这时已经开始给客户端发字了，只能记录，下一个请求会避开这个账号）
  const settle = (errMsg, aborted) => {
    if (aborted && !errMsg) return;
    if (!errMsg) return markResult(acc, 'ok');
    const k = classify(0, errMsg);
    if (k === 'exhausted' || k === 'rate') markResult(acc, k, errMsg);
    else if (!acc.temp) { acc.st.fail++; acc.st.msg = String(errMsg).slice(0, 300); saveAccounts(); }
  };

  // 上游没按 SSE 回，兜底
  const ctype = up.headers.get('content-type') || '';
  if (!ctype.includes('event-stream')) {
    const t = await up.text().catch(() => '');
    let d = null; try { d = JSON.parse(t).data; } catch {}
    if (!d) { finalize(e, st, 'unexpected upstream response'); return oaiError(res, 502, 'unexpected upstream response: ' + t.slice(0, 300), 'upstream_error'); }
    if (d.status === 'failed' || d.error) { finalize(e, st, errText(d.error)); settle(errText(d.error)); return oaiError(res, 502, errText(d.error), 'upstream_error'); }
    const text = outputToText(d.blockOutputs?.[C.SELECTED_OUTPUT] ?? d.output);
    st.text = text || '';
    finalize(e, st, null);
    settle(null);
    fetchRunStats(e, acc);
    return sendWhole(res, payload, model, text, '', extractUsage(d.output));
  }

  const id = 'chatcmpl-' + randomUUID().replace(/-/g, '');
  const created = Math.floor(Date.now() / 1000);

  // ---------- 流式 ----------
  if (payload.stream) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
      ...CORS,
    });
    res.flushHeaders?.();
    req.socket?.setNoDelay?.(true);

    const send = o => res.write(`data: ${JSON.stringify(o)}\n\n`);
    const chunk = (delta, finish = null) => send({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta, finish_reason: finish }] });
    const ping = setInterval(() => res.write(': ping\n\n'), C.PING_MS);

    chunk({ role: 'assistant', content: '' });
    let sent = 0, usage = null, errMsg = null, terminal = false;
    try {
      for await (const f of simFrames(up.body)) {
        if (f.event === undefined && typeof f.chunk === 'string') {
          if (f.chunk) { if (!st.tFirst) st.tFirst = Date.now(); st.text += f.chunk; chunk({ content: f.chunk }); sent += f.chunk.length; }
        } else if (f.event === 'thinking' && typeof f.data === 'string') {
          if (!st.tThink) st.tThink = Date.now(); st.think += f.data;
          chunk({ reasoning_content: f.data });
        } else if (f.event === 'final') {
          terminal = true;
          const d = f.data || {};
          if (d.success === false) errMsg = errText(d.error) || 'workflow failed';
          else if (!sent) { const t = outputToText(d.output); if (t && t !== '{}') { if (!st.tFirst) st.tFirst = Date.now(); st.text += t; chunk({ content: t }); } }
          usage = extractUsage(d.output);
          break;
        } else if (f.event === 'error') {
          terminal = true; errMsg = errText(f.error) || 'sim stream error'; break;
        } else if (f.event === 'stream_error') {
          console.warn('[sim] stream_error:', errText(f.error));
        }
        // chunk_reset：工具调用中间轮的临时文本，已发给客户端的无法撤回，忽略
      }
      if (!terminal && !errMsg && !sent && !ac.signal.aborted) errMsg = '上游流提前结束，没有任何输出';
    } catch (err) {
      if (!ac.signal.aborted) errMsg = 'stream read failed: ' + err.message;
    } finally {
      clearInterval(ping);
    }
    finalize(e, st, errMsg || (ac.signal.aborted && !terminal ? '客户端中途断开' : null));
    settle(errMsg, ac.signal.aborted && !terminal);
    fetchRunStats(e, acc);
    if (res.writableEnded || res.destroyed) return;
    if (errMsg) chunk({ content: `\n[sim error] ${errMsg}` });
    chunk({}, 'stop');
    if (payload.stream_options?.include_usage) {
      send({ id, object: 'chat.completion.chunk', created, model, choices: [], usage: usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 } });
    }
    res.write('data: [DONE]\n\n');
    res.end();
    ac.abort();
    return;
  }

  // ---------- 非流式：内部仍走流，累积后一次性返回 ----------
  let text = '', reasoning = '', usage = null, errMsg = null;
  try {
    for await (const f of simFrames(up.body)) {
      if (f.event === undefined && typeof f.chunk === 'string') { if (f.chunk && !st.tFirst) st.tFirst = Date.now(); text += f.chunk; }
      else if (f.event === 'chunk_reset') text = '';
      else if (f.event === 'thinking' && typeof f.data === 'string') { if (!st.tThink) st.tThink = Date.now(); reasoning += f.data; st.think += f.data; }
      else if (f.event === 'final') {
        const d = f.data || {};
        if (d.success === false) errMsg = errText(d.error) || 'workflow failed';
        else if (!text) { const t = outputToText(d.output); if (t !== '{}') text = t; }
        usage = extractUsage(d.output);
        break;
      } else if (f.event === 'error') { errMsg = errText(f.error); break; }
    }
  } catch (err) { errMsg = 'stream read failed: ' + err.message; }
  st.text = text; if (text && !st.tFirst) st.tFirst = Date.now();
  finalize(e, st, errMsg);
  settle(errMsg);
  fetchRunStats(e, acc);
  ac.abort();
  if (errMsg) return oaiError(res, 502, errMsg, 'upstream_error');
  sendWhole(res, payload, model, text, reasoning, usage, id, created);
}

function sendWhole(res, payload, model, text, reasoning, usage, id, created) {
  id = id || 'chatcmpl-' + randomUUID().replace(/-/g, '');
  created = created || Math.floor(Date.now() / 1000);
  usage = usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 };
  if (payload.stream) {
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', ...CORS });
    const c = (delta, fr = null) => res.write(`data: ${JSON.stringify({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta, finish_reason: fr }] })}\n\n`);
    c({ role: 'assistant', content: text }); c({}, 'stop');
    res.write('data: [DONE]\n\n'); return res.end();
  }
  const message = { role: 'assistant', content: text };
  if (reasoning) message.reasoning_content = reasoning;
  json(res, 200, { id, object: 'chat.completion', created, model, choices: [{ index: 0, message, finish_reason: 'stop' }], usage });
}

// ===================== 管理接口（面板 / 浏览器扩展） =====================
function bearerOf(req) { return (req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim(); }
function adminAuth(req, u) {
  if (!C.PROXY_KEY) return true;
  const k = bearerOf(req) || req.headers['x-admin-key'] || u.searchParams.get('key') || '';
  return k === C.PROXY_KEY;
}
function publicConfig() {
  return {
    SIM_BASE: C.SIM_BASE, SIM_API_KEY: mask(C.SIM_API_KEY), SIM_API_KEY_SET: !!C.SIM_API_KEY,
    PROXY_KEY_SET: !!C.PROXY_KEY, WORKFLOW_ID: C.WORKFLOW_ID, MODELS: C.MODELS,
    INPUT_FIELD: C.INPUT_FIELD, SELECTED_OUTPUT: C.SELECTED_OUTPUT, HISTORY_MODE: C.HISTORY_MODE,
    INCLUDE_THINKING: C.INCLUDE_THINKING ? '1' : '0', DEBUG: String(C.DEBUG),
    STRIP_ABSOLUTE_ZERO: C.STRIP_ABSOLUTE_ZERO ? '1' : '0', FETCH_RUN_STATS: C.FETCH_RUN_STATS ? '1' : '0',
    FAST_TPS_WARN: C.FAST_TPS_WARN, PORT: C.PORT, PROMPT_LOG: C.PROMPT_LOG,
    ROTATE_MODE: C.ROTATE_MODE, FAILOVER: C.FAILOVER ? '1' : '0', MAX_SWITCH: C.MAX_SWITCH,
    EXHAUST_MARGIN: C.EXHAUST_MARGIN, AUTO_CHECK_MIN: C.AUTO_CHECK_MIN, COOLDOWN_RATE: C.COOLDOWN_RATE, COOLDOWN_ERR: C.COOLDOWN_ERR,
  };
}
function pubAccounts() {
  const now = Date.now();
  const next = pickAccount('', new Set(), ACCS, true);
  return {
    mode: C.ROTATE_MODE, failover: C.FAILOVER, margin: C.EXHAUST_MARGIN, next: next?.id || null,
    accounts: ACCS.map(a => {
      const reason = unusableReason(a, '', now);
      return { id: a.id, name: a.name, key: mask(a.key), workflowId: a.workflowId, enabled: a.enabled, usable: !reason, reason, ...a.st };
    }),
  };
}
async function readJson(req) { try { return JSON.parse(await readBody(req) || '{}'); } catch { return null; } }
const pickIds = ids => (Array.isArray(ids) && ids.length ? ACCS.filter(a => ids.includes(a.id)) : ACCS);
async function admin(req, res, p, u) {
  if (req.method === 'GET' && p === '/admin/status') {
    return json(res, 200, {
      version: VERSION, uptime: Date.now() - STARTED, config: publicConfig(), models: modelIds(),
      localUrl: `http://127.0.0.1:${C.PORT}/v1`, lanUrls: lanUrls(),
      stats: { ...STATS, avgTps: STATS.tpsN ? +(STATS.tpsSum / STATS.tpsN).toFixed(1) : null },
      ready: ACCS.some(a => !unusableReason(a)),
      pool: { mode: C.ROTATE_MODE, total: ACCS.length, usable: ACCS.filter(a => !unusableReason(a)).length },
    });
  }
  // ---------- 账号池 ----------
  if (p.startsWith('/admin/accounts')) {
    if (req.method === 'GET' && p === '/admin/accounts') return json(res, 200, pubAccounts());
    if (req.method === 'GET' && p === '/admin/accounts/export') {
      return json(res, 200, { text: ACCS.map(a => [a.key, a.workflowId, a.name].filter(Boolean).join(' ')).join('\n') });
    }
    if (req.method !== 'POST') return oaiError(res, 404, 'not found');
    const body = await readJson(req);
    if (!body) return oaiError(res, 400, 'invalid JSON');

    if (p === '/admin/accounts/add') {      // {text} 批量导入，或 {key, workflowId, name}
      const items = body.text ? parseImport(body.text) : body.key ? [{ key: String(body.key).trim(), workflowId: String(body.workflowId || '').trim(), name: body.name }] : [];
      if (!items.length) return oaiError(res, 400, '没找到任何 Sim Key（格式 sk-sim-...）');
      let added = 0, updated = 0; const accs = [];
      for (const it of items) { const r = upsertAccount(it); r.added ? added++ : updated++; accs.push(r.acc); }
      console.log(`[账号] 导入：新增 ${added}，更新 ${updated}`);
      await checkMany(accs);
      return json(res, 200, { ok: true, added, updated, ...pubAccounts() });
    }
    if (p === '/admin/accounts/update') {
      const a = ACCS.find(x => x.id === body.id);
      if (!a) return oaiError(res, 404, '账号不存在');
      let reset = false;
      if (typeof body.name === 'string' && body.name.trim()) a.name = body.name.trim();
      if (typeof body.workflowId === 'string' && body.workflowId.trim() !== a.workflowId) { a.workflowId = body.workflowId.trim(); reset = true; }
      if (typeof body.key === 'string' && body.key.trim()) { a.key = body.key.trim(); reset = true; }
      if (typeof body.enabled === 'boolean') a.enabled = body.enabled;
      if (reset) { a.st = { ...ST0(), reqs: a.st.reqs, ok: a.st.ok, fail: a.st.fail, spent: a.st.spent }; checkAccount(a); }
      saveAccounts(true);
      return json(res, 200, { ok: true, ...pubAccounts() });
    }
    if (p === '/admin/accounts/reorder') {  // {ids:[...]} 新顺序
      const order = Array.isArray(body.ids) ? body.ids : [];
      ACCS.sort((x, y) => (order.indexOf(x.id) + 1 || 1e9) - (order.indexOf(y.id) + 1 || 1e9));
      RR = 0; saveAccounts(true);
      return json(res, 200, { ok: true, ...pubAccounts() });
    }
    if (p === '/admin/accounts/bulk') {     // {ids?, action: enable|disable|reset|delete}
      const act = body.action;
      if (act === 'delete') {
        if (!Array.isArray(body.ids) || !body.ids.length) return oaiError(res, 400, '删除必须指定账号');
        const n = ACCS.length; ACCS = ACCS.filter(a => !body.ids.includes(a.id)); RR = 0;
        console.log(`[账号] 已删除 ${n - ACCS.length} 个`);
      } else {
        for (const a of pickIds(body.ids)) {
          if (act === 'enable') a.enabled = true;
          else if (act === 'disable') a.enabled = false;
          else if (act === 'reset') a.st = { ...ST0(), reqs: a.st.reqs, ok: a.st.ok, fail: a.st.fail, spent: a.st.spent, usage: a.st.usage };
        }
      }
      saveAccounts(true);
      return json(res, 200, { ok: true, ...pubAccounts() });
    }
    if (p === '/admin/accounts/check') {    // {ids?, deep?}
      const list = pickIds(body.ids);
      const cnt = await checkMany(list, !!body.deep);
      return json(res, 200, { ok: true, counts: cnt, ...pubAccounts() });
    }
    return oaiError(res, 404, 'not found');
  }
  if (req.method === 'GET' && p === '/admin/logs') {
    return json(res, 200, { logs: LOGS.slice(-Number(u.searchParams.get('limit') || 100)) });
  }
  if (req.method === 'POST' && p === '/admin/logs/clear') {
    LOGS.length = 0; Object.assign(STATS, { total: 0, ok: 0, err: 0, tpsSum: 0, tpsN: 0, cost: 0 });
    return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && p === '/admin/config') {
    let body; try { body = JSON.parse(await readBody(req) || '{}'); } catch { return oaiError(res, 400, 'invalid JSON'); }
    const upd = {};
    for (const k of EDITABLE) {
      if (body[k] === undefined || body[k] === null) continue;
      const v = String(body[k]).replace(/[\r\n]/g, '').trim();
      if (v === '' && k !== 'PROXY_KEY') continue;   // 留空 = 不修改
      upd[k] = v;
    }
    if (body.MODEL_NAME) {
      const name = String(body.MODEL_NAME).trim();
      const wf = upd.WORKFLOW_ID || C.WORKFLOW_ID;
      if (name && wf) upd.MODELS = JSON.stringify({ [name]: wf });
    }
    if (upd.MODELS) { try { JSON.parse(upd.MODELS); } catch { return oaiError(res, 400, 'MODELS 必须是合法 JSON'); } }
    if (upd.ROTATE_MODE && !['priority', 'round'].includes(upd.ROTATE_MODE)) return oaiError(res, 400, 'ROTATE_MODE 只能是 priority 或 round');
    // 兼容旧扩展 / 面板：推送的 SIM_API_KEY + WORKFLOW_ID 不再覆盖 .env，而是加进账号池
    let account = null;
    if (upd.SIM_API_KEY) {
      const { acc, added } = upsertAccount({ key: upd.SIM_API_KEY, workflowId: upd.WORKFLOW_ID || C.WORKFLOW_ID, name: body.ACCOUNT_NAME });
      account = { name: acc.name, added, total: ACCS.length };
      console.log(`[账号] ${added ? '新增' : '更新'}账号：${acc.name}（来自${req.headers['x-client'] === 'extension' ? '浏览器扩展' : '管理面板'}）`);
      delete upd.SIM_API_KEY;
      if (C.WORKFLOW_ID) delete upd.WORKFLOW_ID;      // 工作流跟着账号走；只有还没有默认工作流时才顺便写进 .env
      checkAccount(acc);
    }
    if (!Object.keys(upd).length && !account) return oaiError(res, 400, '没有要修改的字段');
    if (Object.keys(upd).length) writeEnv(upd);
    if (Object.keys(upd).length) console.log(`[配置] 已通过${req.headers['x-client'] === 'extension' ? '浏览器扩展' : '管理面板'}更新: ${Object.keys(upd).join(', ')}`);
    return json(res, 200, { ok: true, updated: Object.keys(upd), account, config: publicConfig() });
  }
  return oaiError(res, 404, 'not found');
}

function serveFile(res, file, type) {
  fs.readFile(file, (err, buf) => {
    if (err) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end('<h3>找不到 public/index.html</h3><p>请确认压缩包完整解压，public 文件夹与 sim2openai.mjs 在同一目录。</p>');
    }
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
}

// ===================== 路由 =====================
const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
    const u = new URL(req.url, 'http://x');
    const p = u.pathname.replace(/\/+$/, '') || '/';

    if (req.method === 'GET' && (p === '/' || p === '/index.html' || p === '/panel')) return serveFile(res, path.join(PUBLIC_DIR, 'index.html'), 'text/html; charset=utf-8');
    if (p === '/favicon.ico') { res.writeHead(204); return res.end(); }
    if (p === '/health') return json(res, 200, { ok: true, version: VERSION });
    if (p.startsWith('/admin/')) {
      if (!adminAuth(req, u)) return oaiError(res, 401, '管理密钥错误（就是 .env 里的 PROXY_KEY）', 'invalid_request_error');
      return await admin(req, res, p, u);
    }

    const bearer = bearerOf(req);
    let passKey = '';
    if (C.PROXY_KEY) {
      if (bearer !== C.PROXY_KEY) return oaiError(res, 401, 'invalid api key（与 .env 里的 PROXY_KEY 不一致）', 'invalid_request_error');
    } else if (bearer.startsWith('sk-sim-')) passKey = bearer;

    if (req.method === 'GET' && (p === '/v1/models' || p === '/models')) {
      return json(res, 200, { object: 'list', data: modelIds().map(id => ({ id, object: 'model', created: 0, owned_by: 'sim' })) });
    }
    if (req.method === 'POST' && (p === '/v1/chat/completions' || p === '/chat/completions')) {
      return await chatCompletions(req, res, passKey);
    }
    oaiError(res, 404, 'not found');
  } catch (err) {
    console.error('[server]', err);
    if (!res.headersSent) oaiError(res, 500, err.message); else res.end();
  }
});
server.on('error', err => {
  if (err.code === 'EADDRINUSE') { console.error(`\n[X] 端口 ${C.PORT} 已被占用：可能已经开着一个反代窗口，或者在 .env 里改 PORT\n`); process.exit(1); }
  throw err;
});
server.listen(C.PORT, C.HOST, () => {
  console.log(`\n  ███ Sim2OpenAI v${VERSION}  ->  ${C.SIM_BASE}`);
  console.log(`  管理面板 : http://127.0.0.1:${C.PORT}/`);
  console.log(`  本机接口 : http://127.0.0.1:${C.PORT}/v1`);
  for (const l of lanUrls()) console.log(`  局域网   : ${l}`);
  console.log(`  API Key  : ${C.PROXY_KEY ? '客户端填 .env 里的 PROXY_KEY' : '（未设置 PROXY_KEY，客户端填 Sim key 透传）'}`);
  console.log(`  模型     : ${modelIds().join(', ')}   工作流: ${C.WORKFLOW_ID || '(空)'}`);
  console.log(`  账号池   : ${ACCS.length} 个（${C.ROTATE_MODE === 'round' ? '② 分散轮询' : '① 优先模式'}，失败换号=${C.FAILOVER ? '开' : '关'}，定时验活=${C.AUTO_CHECK_MIN ? C.AUTO_CHECK_MIN + ' 分钟' : '关'}）`);
  ACCS.forEach((a, i) => console.log(`             ${i + 1}. ${a.name}  ${mask(a.key)}  ${a.workflowId ? a.workflowId.slice(0, 8) + '…' : '(默认工作流)'}${a.enabled ? '' : '  [已停用]'}`));
  console.log(`  DEBUG=${C.DEBUG}   自动删 Absolute zero=${C.STRIP_ABSOLUTE_ZERO ? '开' : '关'}`);
  if (!ACCS.length) console.log('\n  ⚠ 账号池是空的：打开管理面板添加，或在 sim.ai 页面点浏览器扩展“一键配置”。');
  console.log('');
  if (ACCS.some(a => a.enabled)) setTimeout(() => checkMany(ACCS.filter(a => a.enabled)).catch(() => {}), 1500);
});
