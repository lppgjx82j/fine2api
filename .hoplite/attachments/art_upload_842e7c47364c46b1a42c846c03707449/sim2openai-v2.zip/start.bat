@echo off
chcp 65001 >nul
title Sim2OpenAI Proxy
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js not found. Please install Node.js 18+ : https://nodejs.org
  start "" https://nodejs.org/
  pause
  exit /b 1
)

for /f "tokens=1 delims=v." %%a in ('node -v') do set NODEMAJOR=%%a
if %NODEMAJOR% LSS 18 (
  echo [X] Node.js v%NODEMAJOR% is too old, need 18 or newer.
  pause
  exit /b 1
)

if not exist ".env" (
  if exist ".env.example" (
    copy ".env.example" ".env" >nul
    echo [i] .env created from .env.example
  )
)

set PORT=8787
if exist ".env" (
  for /f "tokens=1,* delims==" %%a in ('findstr /b /i "PORT=" ".env"') do set PORT=%%b
)

echo [i] Starting Sim2OpenAI on port %PORT% ...
start "" /b cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:%PORT%/"

:run
node sim2openai.mjs
echo.
echo [!] Proxy stopped (exit code %errorlevel%).
choice /c RQ /n /m "Press R to restart, Q to quit: "
if errorlevel 2 exit /b 0
goto run
