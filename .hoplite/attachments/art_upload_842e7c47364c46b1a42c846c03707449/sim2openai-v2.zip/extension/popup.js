// Sim2OpenAI 助手 — popup
// 所有 sim.ai 接口都在 sim.ai 标签页里执行（同源 + 登录 cookie），不需要你手动复制任何东西。

const $ = id => document.getElementById(id);
let tab = null, ws = '', wf = '';

function log(msg, cls = '') {
  const d = document.createElement('div');
  d.className = 'l ' + cls;
  d.textContent = `[${new Date().toLocaleTimeString('zh-CN', { hour12: false })}] ${msg}`;
  $('log').prepend(d);
}
function busy(on) { for (const id of ['go', 'keyOnly', 'pushOnly', 'ping']) $(id).disabled = on; }
const model = () => ($('modelSel').value === '__custom' ? $('modelCustom').value.trim() : $('modelSel').value);
const proxyUrl = () => ($('proxyUrl').value.trim() || 'http://127.0.0.1:8787').replace(/\/+$/, '');

async function saveSettings() {
  await chrome.storage.local.set({
    proxyUrl: $('proxyUrl').value.trim(), proxyKey: $('proxyKey').value, wfName: $('wfName').value.trim(),
    modelSel: $('modelSel').value, modelCustom: $('modelCustom').value.trim(), newWf: $('newWf').checked,
  });
}

// ============ 在 sim.ai 页面里执行的函数（必须自包含，不能引用外部变量） ============
async function simOps(op, p) {
  const j = async (method, url, body) => {
    const r = await fetch(url, {
      method, credentials: 'include',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const t = await r.text();
    let d; try { d = JSON.parse(t); } catch { d = t; }
    if (!r.ok) {
      const m = typeof d === 'string' ? d.slice(0, 200) : (d.error?.message || d.error || JSON.stringify(d).slice(0, 300));
      const e = new Error(`${method} ${url} → ${r.status}: ${typeof m === 'string' ? m : JSON.stringify(m)}`);
      e.status = r.status; throw e;
    }
    return d;
  };
  const uid = () => crypto.randomUUID();
  const norm = s => String(s || '').toLowerCase().replace(/\s+/g, '');
  try {
    if (op === 'createWorkflow') {
      const d = await j('POST', '/api/workflows', { name: p.name, workspaceId: p.workspaceId });
      return { ok: true, id: d.id || d.workflow?.id, name: d.name };
    }

    if (op === 'configure') {
      const st = await j('GET', `/api/workflows/${p.workflowId}/state`);
      const blocks = st.blocks || {};
      const edges = Array.isArray(st.edges) ? st.edges : [];
      const all = Object.values(blocks);
      const start = all.find(b => b.type === 'start_trigger') || all.find(b => /start/i.test(b.type));
      if (!start) throw new Error('工作流里没有 Start 块（请在编辑器里先加一个 Start）');

      // 1) Start 块确保有输入字段
      start.subBlocks = start.subBlocks || {};
      const inf = start.subBlocks.inputFormat || { id: 'inputFormat', type: 'input-format', value: [] };
      let fields = Array.isArray(inf.value) ? inf.value.filter(f => f && typeof f === 'object') : [];
      let addedField = false;
      if (!fields.some(f => f.name === p.inputField)) {
        fields = fields.filter(f => f.name); // 去掉空白占位字段
        fields.push({ id: uid(), name: p.inputField, type: 'string', value: '', collapsed: false });
        addedField = true;
      }
      start.subBlocks.inputFormat = { ...inf, id: 'inputFormat', type: 'input-format', value: fields };

      // 2) 找/建 Agent 块
      const agents = all.filter(b => b.type === 'agent');
      let agent = agents.find(a => norm(a.name) === 'agent') || agents[0];
      let createdAgent = false;
      if (!agent) {
        const id = uid();
        agent = {
          id, type: 'agent', name: 'Agent',
          position: { x: (start.position?.x || 0) + 480, y: start.position?.y || 0 },
          subBlocks: {}, outputs: {}, enabled: true, horizontalHandles: true, advancedMode: false,
          errorEnabled: false, triggerMode: false, height: 0, data: {}, locked: false,
        };
        blocks[id] = agent; createdAgent = true;
      }
      agent.subBlocks = agent.subBlocks || {};
      const oldModel = agent.subBlocks.model?.value;
      agent.subBlocks.model = { ...(agent.subBlocks.model || {}), id: 'model', type: 'combobox', value: p.model };
      const ref = `<${norm(start.name) || 'start'}.${p.inputField}>`;
      const msgs = Array.isArray(agent.subBlocks.messages?.value) ? agent.subBlocks.messages.value : [];
      let resetMsgs = false;
      if (!msgs.some(m => String(m?.content || '').includes(ref))) {
        agent.subBlocks.messages = { ...(agent.subBlocks.messages || {}), id: 'messages', type: 'messages-input', value: [{ role: 'user', content: ref }] };
        resetMsgs = true;
      }

      // 3) 连线 Start -> Agent
      if (!edges.some(e => e.source === start.id && e.target === agent.id)) {
        edges.push({ id: uid(), source: start.id, target: agent.id, sourceHandle: 'source', targetHandle: 'target' });
      }

      const body = { blocks, edges, loops: st.loops || {}, parallels: st.parallels || {}, lastSaved: Date.now() };
      const vars = st.variables && Object.keys(st.variables).length ? st.variables : null;
      if (vars) {
        body.variables = {};
        for (const [k, v] of Object.entries(vars)) { const { workflowId, ...rest } = v || {}; body.variables[k] = rest; }
      }
      try { await j('PUT', `/api/workflows/${p.workflowId}/state`, body); }
      catch (e) { if (vars && e.status === 400) { delete body.variables; await j('PUT', `/api/workflows/${p.workflowId}/state`, body); } else throw e; }

      return { ok: true, createdAgent, addedField, resetMsgs, oldModel: oldModel || null, agentName: agent.name, selectedOutput: `${norm(agent.name)}.content`, inputRef: ref };
    }

    if (op === 'deploy') {
      let r;
      try { r = await j('POST', `/api/workflows/${p.workflowId}/deploy`, {}); }
      catch (e) { if (e.status === 400 || e.status === 415) r = await j('POST', `/api/workflows/${p.workflowId}/deploy`); else throw e; }
      return { ok: true, deployed: r?.isDeployed !== false, warnings: r?.warnings || [] };
    }

    if (op === 'createKey') {
      const d = await j('POST', '/api/users/me/api-keys', { name: p.name });
      const key = d.key?.key || d.key;
      if (typeof key !== 'string' || !key.startsWith('sk-')) throw new Error('创建成功但没拿到明文 key：' + JSON.stringify(d).slice(0, 200));
      return { ok: true, key, name: d.key?.name || p.name };
    }

    if (op === 'listWorkflows') {
      const d = await j('GET', '/api/workflows?workspaceId=' + encodeURIComponent(p.workspaceId));
      return { ok: true, list: (d.data || []).map(w => ({ id: w.id, name: w.name })) };
    }
    return { ok: false, error: '未知操作 ' + op };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function runInPage(op, params) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: simOps, args: [op, params] });
  const v = r?.result;
  if (!v) throw new Error('页面脚本没有返回结果（请刷新 sim.ai 页面后重试）');
  if (!v.ok) throw new Error(v.error || '未知错误');
  return v;
}

async function pushProxy(cfg) {
  const r = await fetch(proxyUrl() + '/admin/config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + $('proxyKey').value, 'X-Client': 'extension' },
    body: JSON.stringify(cfg),
  });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) throw new Error('反代密钥不对（填 .env 里的 PROXY_KEY）');
  if (!r.ok) throw new Error(d.error?.message || 'HTTP ' + r.status);
  return d;
}

function showResult(cfg, pushed) {
  const env = `${cfg.SIM_API_KEY} ${cfg.WORKFLOW_ID} ${cfg.ACCOUNT_NAME || ''}`.trim();
  const box = $('result');
  box.hidden = false;
  box.innerHTML = `${pushed ? `✅ 已加入反代账号池${pushed.name ? '：<b>' + pushed.name + '</b>' + (pushed.added ? '（新增，共 ' + pushed.total + ' 个）' : '（已存在，已更新）') : ''}` : '⚠ 没能推送到反代（反代没开？），可以复制下面的内容，在反代面板「账号池 → 批量导入」里粘贴'}<br>
    Key：<code>${cfg.SIM_API_KEY.slice(0, 10)}…${cfg.SIM_API_KEY.slice(-4)}</code><br>
    工作流：<code>${cfg.WORKFLOW_ID}</code><br>模型：<code>${cfg.MODEL_NAME}</code> · 输出：<code>${cfg.SELECTED_OUTPUT}</code><br>
    <button id="copyEnv" style="margin-top:6px">复制账号行（用于批量导入）</button>`;
  $('copyEnv').onclick = () => navigator.clipboard.writeText(env).then(() => log('已复制，可粘贴到反代面板「批量导入」', 'ok'));
}

async function finish(cfg) {
  // 用当前登录的 sim.ai 邮箱给账号命名，方便在账号池里区分
  if (!cfg.ACCOUNT_NAME) {
    try {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN',
        func: async () => { try { const d = await (await fetch('/api/auth/get-session', { credentials: 'include' })).json(); return d?.user?.email || d?.user?.name || ''; } catch { return ''; } },
      });
      if (r?.result) cfg.ACCOUNT_NAME = r.result;
    } catch {}
  }
  await chrome.storage.local.set({ lastCfg: cfg });
  log('推送到反代账号池 ' + proxyUrl() + ' …');
  try {
    const d = await pushProxy(cfg);
    log(`✓ 已${d.account?.added === false ? '更新' : '加入'}账号池${d.account ? '：' + d.account.name : ''}，可以直接在酒馆里用了`, 'ok');
    showResult(cfg, d.account || { name: '' });
  }
  catch (e) { log('✗ 推送失败：' + e.message, 'err'); showResult(cfg, false); }
}

async function oneClick() {
  const m = model();
  if (!m) return log('请先填写模型 ID', 'err');
  await saveSettings(); busy(true);
  try {
    let id = wf;
    if (!id || $('newWf').checked) {
      log('创建新工作流…');
      const r = await runInPage('createWorkflow', { workspaceId: ws, name: $('wfName').value.trim() || 'sim2openai' });
      id = r.id; log('✓ 工作流已创建 ' + id, 'ok');
    }
    log(`配置 Start / Agent 块，模型 = ${m} …`);
    const c = await runInPage('configure', { workflowId: id, model: m, inputField: 'message' });
    log(`✓ ${c.createdAgent ? '已新建 Agent 块' : `已更新 Agent 块「${c.agentName}」`}${c.oldModel && c.oldModel !== m ? `（模型 ${c.oldModel} → ${m}）` : ''}`, 'ok');
    if (c.addedField) log('✓ Start 块已添加输入字段 message', 'ok');
    if (c.resetMsgs) log(`ℹ Agent 的 Messages 已设为 ${c.inputRef}（反代会把整段对话放进这个字段）`, 'warn');
    log('部署工作流…');
    const d = await runInPage('deploy', { workflowId: id });
    log('✓ 已部署' + (d.warnings?.length ? '（警告：' + d.warnings.join('；') + '）' : ''), 'ok');
    log('创建 API Key…');
    const k = await runInPage('createKey', { name: 'sim2openai-' + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '') });
    log('✓ Key 已创建：' + k.name, 'ok');
    await finish({ SIM_API_KEY: k.key, WORKFLOW_ID: id, MODEL_NAME: m, INPUT_FIELD: 'message', SELECTED_OUTPUT: c.selectedOutput });
    wf = id;
    log('刷新 sim.ai 页面以显示新配置…');
    await chrome.tabs.update(tab.id, { url: `https://www.sim.ai/workspace/${ws}/w/${id}` });
  } catch (e) {
    log('✗ ' + e.message, 'err');
    if (/→ 40[13]/.test(e.message)) log('提示：确认已登录 sim.ai，并且对该工作区有编辑权限', 'warn');
  } finally { busy(false); }
}

async function keyOnly() {
  if (!wf) return log('当前页面不是某个工作流（URL 里没有 /w/xxx），请先打开工作流', 'err');
  await saveSettings(); busy(true);
  try {
    log('创建 API Key…');
    const k = await runInPage('createKey', { name: 'sim2openai-' + Date.now().toString(36) });
    log('✓ Key 已创建', 'ok');
    const name = model() || 'gemini-4-argon';
    await finish({ SIM_API_KEY: k.key, WORKFLOW_ID: wf, MODEL_NAME: name, INPUT_FIELD: 'message', SELECTED_OUTPUT: 'agent.content' });
    log('ℹ 未改动工作流；如果 Agent 块不叫 Agent，请在反代面板改“输出字段”', 'warn');
  } catch (e) { log('✗ ' + e.message, 'err'); } finally { busy(false); }
}

async function pushOnly() {
  const { lastCfg } = await chrome.storage.local.get('lastCfg');
  if (!lastCfg) return log('还没有可推送的结果，先点“一键配置”', 'err');
  await saveSettings(); busy(true);
  try { await finish(lastCfg); } finally { busy(false); }
}

async function ping() {
  await saveSettings();
  try {
    const r = await fetch(proxyUrl() + '/admin/status', { headers: { 'Authorization': 'Bearer ' + $('proxyKey').value } });
    if (r.status === 401) return log('反代在运行，但密钥不对', 'err');
    const d = await r.json();
    log(`✓ 反代 v${d.version} 运行中 · 模型 ${d.models.join(',')} · ${d.ready ? '已就绪' : '未配置'}`, 'ok');
  } catch { log('✗ 连不上 ' + proxyUrl() + '（反代没启动？双击 start.bat）', 'err'); }
}

async function init() {
  const s = await chrome.storage.local.get(['proxyUrl', 'proxyKey', 'wfName', 'modelSel', 'modelCustom', 'newWf']);
  $('proxyUrl').value = s.proxyUrl || 'http://127.0.0.1:8787';
  $('proxyKey').value = s.proxyKey || '';
  $('wfName').value = s.wfName || 'sim2openai';
  $('modelSel').value = s.modelSel || 'gemini-4-argon';
  $('modelCustom').value = s.modelCustom || '';
  $('modelCustom').hidden = $('modelSel').value !== '__custom';
  $('newWf').checked = !!s.newWf;

  $('modelSel').onchange = () => { $('modelCustom').hidden = $('modelSel').value !== '__custom'; };
  $('go').onclick = oneClick;
  $('keyOnly').onclick = keyOnly;
  $('pushOnly').onclick = pushOnly;
  $('ping').onclick = ping;
  $('openPanel').onclick = () => chrome.tabs.create({ url: proxyUrl() + '/' });

  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const m = (tab?.url || '').match(/^https:\/\/(?:www\.)?sim\.ai\/workspace\/([^/?#]+)(?:\/w\/([^/?#]+))?/);
  if (!m) {
    $('ctx').innerHTML = '⚠ 当前标签页不是 sim.ai 工作区。请先 <a href="https://www.sim.ai/" target="_blank">打开 sim.ai</a> 并登录，进入任意工作区或工作流后再点扩展。';
    for (const id of ['go', 'keyOnly']) $(id).disabled = true;
    return;
  }
  ws = m[1]; wf = m[2] || '';
  $('ctx').innerHTML = `工作区：<b>${ws.slice(0, 8)}…</b><br>工作流：${wf ? `<b>${wf}</b>` : '（未打开，将新建）'}`;
  if (!wf) $('newWf').checked = true;
}
init();
