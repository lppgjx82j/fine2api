# Sim2OpenAI v2.1

## 多账号池（v2.1 新增）
- 账号存在 `accounts.json`（自动生成）。首次启动会把 `.env` 里的 `SIM_API_KEY` + `WORKFLOW_ID` 导入为“账号1”。
- 每个账号 = **Key + 该账号自己的工作流 ID**（A 账号的 Key 调不了 B 账号的工作流）。
- 面板「账号池」：添加/批量导入（每行 `Key 工作流ID 名称`）、↑↓ 排序、启停、编辑、导出、清理失效。
- **① 优先模式**：一直用排第一的可用账号，剩余额度 < `EXHAUST_MARGIN` 或出错才顺延。
- **② 分散轮询**：每个请求轮流换号。
- **失败自动换号**：还没出字时遇到 402/401/403/404/429/5xx/网络错误，立刻换下一个账号重发，酒馆无感。
- **批量验活**（免费）：查 `/api/users/me/usage-limits` 额度 + `/api/workflows/{id}/status` 部署状态；**深度验活**再真实调用一次（每个约 $0.001）。启动时和每 `AUTO_CHECK_MIN` 分钟自动快速验活。
- 浏览器扩展“一键配置”现在是**追加**账号到池里（用 sim.ai 登录邮箱命名），不再覆盖。换一个 sim.ai 账号登录再点一次，就多一个号。

把 sim.ai 工作流变成 OpenAI 兼容接口，给 SillyTavern / Cherry Studio 等客户端用。

## 文件
```
sim2openai-v2/
├─ start.bat            双击一键启动（检查 Node、自动打开面板、崩溃可按 R 重启）
├─ sim2openai.mjs       反代主程序（Node 18+，零依赖）
├─ .env                 配置（已填好你当前的 key 和工作流）
├─ .env.example         空白模板
├─ public/index.html    管理面板 http://127.0.0.1:8787/
└─ extension/           Chrome 扩展（一键配置 sim.ai）
```

## 1. 启动反代
双击 `start.bat`，浏览器会自动打开管理面板，用 `.env` 里的 `PROXY_KEY` 登录。

面板功能：
- 接入地址（本机 + 局域网）一键复制
- 实时统计：请求数、平均出字速度、Sim 记录的费用、速度曲线
- 请求日志：首字时间、出字速度、**Sim 实测 tok/s**、真实 token（含缓存）、费用；速度 ≥ 140 tok/s 标红“疑似降级”
- 在线改配置，保存后立即生效（写回 .env，不用重启）
- 快速测试：直接发一条消息看速度

## 2. 安装 Chrome 扩展
1. 打开 `chrome://extensions`，右上角打开 **开发者模式**
2. 点 **加载已解压的扩展程序**，选择 `extension` 文件夹
3. 打开 sim.ai 并登录，进入工作区（或某个工作流）
4. 点扩展图标 → 选模型 → 填反代密钥（PROXY_KEY）→ **⚡ 一键配置**

一键配置会依次：
1. （没打开工作流或勾选“新建”时）创建工作流
2. Start 块加 `message` 输入；找到/新建 Agent 块，设置模型，Messages 设为 `<start.message>`，连线
3. 部署工作流
4. 创建一个新的个人 API Key
5. 推送到反代：自动写入 `.env` 并热重载，酒馆马上能用

推送失败时（反代没开），扩展会显示结果，可以复制 `.env` 片段手动粘贴。

## 3. SillyTavern 设置
API：Chat Completion → 来源 Custom (OpenAI-compatible)
- 地址：`http://127.0.0.1:8787/v1`（其他设备用面板上的局域网地址）
- Key：`PROXY_KEY`
- 模型：`gemini-4-argon`

## 主要配置项
| 配置 | 说明 |
|---|---|
| `DEBUG` | 0 关 / 1 出字速度 / 2 速度+原始帧 / 3 速度+保存提示词到 prompts.txt |
| `STRIP_ABSOLUTE_ZERO` | 1=自动删掉 `[Absolute zero system prompt: ...]`（实测会触发 240 tok/s 的降级路径） |
| `FETCH_RUN_STATS` | 1=每次调用后用 run id 回查 Sim 记录的真实 token / 费用 / 模型 |
| `FAST_TPS_WARN` | 超过这个速度标记疑似降级，默认 140 |

## 注意
- `.env` 现在**文件优先**于系统环境变量，改完自动热重载；改 `PORT` / `HOST` 要重启。
- 浏览器扩展用的是 sim.ai 网页自己的内部接口（参考 Sim 开源代码），sim.ai 改版后可能失效；失效时到 sim.ai 手动配置，再用“只建 Key 并推送”或在面板里填写。
- 每轮 14 万字的长提示词大约花 $0.3（12 月 1 日起 Argon 价格翻倍）。
