# 安全审计摘要

审计范围：压缩包内 15 个原始文件，以及为 VPS 部署新增的 Docker/Nginx/部署文件。审计方式为人工静态检查、危险调用模式搜索和 Python 语法编译检查；没有运行第三方凭证，也没有把项目连接到真实 Omnara 账号。

## 原始代码中没有发现

- `eval`、`exec`、`subprocess`、`os.system`、反弹 Shell 或下载执行器；
- 自启动、定时任务、SSH key 修改、Docker socket 操作或权限提升代码；
- `pickle`/不安全 YAML 反序列化；
- 把环境变量或 Token 主动发送到非 Omnara 目标的逻辑。

原代码的外部 HTTP 请求集中在 `OMNARA_API`，默认是 `https://api.omnara.com/v1`，通过 `Authorization: Bearer ...` 访问其 API。图片 data URL 会被转发给 Omnara，这是其多模态输入功能的一部分，不是隐藏外传。

## 已修复的部署风险

- 生产环境强制要求 `GATEWAY_API_KEY`；
- 应用只发布到宿主机 `127.0.0.1:8787`，公网入口仅为 Nginx；
- 关闭 Swagger/OpenAPI 公共文档；
- 健康检查分为不泄露信息的 `/healthz` 和需要 API Key 的详细 `/health`；
- 去掉默认全开放 CORS，增加请求体大小限制；
- 容器使用非 root 用户、只读根文件系统、丢弃 Linux capabilities 和 `no-new-privileges`；
- Nginx 强制 HTTPS、关闭代理缓冲、支持 SSE 流式响应和大请求体，并设置长连接超时；
- 部署脚本不会用空配置覆盖已有 `.env`，并将其权限设为 `0600`。

## 仍需注意

这不是形式化证明，也不能保证依赖库或上游 Omnara API 永远没有漏洞。建议定期重建镜像获取安全更新，并及时轮换 Omnara Token 与网关 API Key。应用接收到的聊天内容会按其设计发送给 Omnara 服务。