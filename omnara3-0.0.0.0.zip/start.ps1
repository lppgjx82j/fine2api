﻿Set-Location $PSScriptRoot

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Error "找不到 python。请先安装 Python 3.11+"
    exit 1
}

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

$py = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
& $py -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host ""
    Write-Host "已创建 .env。请先编辑它，填入 OMNARA_TOKEN。"
    Write-Host "Token 来自 https://app.omnara.com → API Tokens → New token"
    Write-Host "填好后重新运行本脚本，或先执行:  .\.venv\Scripts\python check_token.py"
    exit 1
}

Write-Host "正在校验 Omnara Token..."
& $py check_token.py
$code = $LASTEXITCODE
if ($code -eq 1 -or $code -eq 2) { exit $code }
if ($code -eq 3) {
    Write-Host "Token 可用，但还没有授权模型。先去控制台加 Provider 再回来。"
    exit 3
}

$hostName = "0.0.0.0"
$port = "8787"
Get-Content ".env" | ForEach-Object {
    if ($_ -match '^\s*HOST\s*=\s*(.+)$') { $hostName = $Matches[1].Trim() }
    if ($_ -match '^\s*PORT\s*=\s*(.+)$') { $port = $Matches[1].Trim() }
}

Write-Host ""
Write-Host "酒馆 API URL : http://$hostName`:$port/v1"
Write-Host "API Key      : 留空 GATEWAY_API_KEY 时填 .env 里的 OMNARA_TOKEN"
Write-Host ""
& $py -m uvicorn app.main:app --host $hostName --port $port
