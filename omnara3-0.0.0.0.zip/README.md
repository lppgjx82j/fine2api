# omnara-4

Omnara Agent API → OpenAI 兼容接口的反代网关。多 Token 轮换、无状态会话、机器/沙箱费用自动清理。

## 功能

- **OpenAI 兼容**：`/v1/chat/completions`、`/v1/models`，酒馆（SillyTavern）/Cherry Studio/new-api 等客户端直接接入
- **多 Token 轮换**：`.env` 里逗号分隔多个 Omnara Token，自动轮换 + 故障切换（401/403/404/429 自动换下一个）
- **无状态模式**：每次请求创建新 Agent，完整历史编入 instruction，杜绝上下文串台
- **机器费用清理**：后台自动扫描删除残留沙箱机器，池闲置阈值压到 5 分钟
- **流式/非流式**：支持 SSE 流式输出，含 reasoning_content（思考过程）
- **模型名校验**：只认完整模型名，匹配不上立即报错并列出可用清单——绝不静默换模型

## 快速部署

```bash
# 解压到 /opt
cd /opt && unzip -o omnara-4.zip

# 一键部署（需 root，自动装 Docker 容器 + nginx 反代）
sudo bash /opt/omnara3/deploy.sh

# 若本机 8787 已被其他项目占用，指定空闲宿主端口（如 38218）：
HOST_PORT=38218 sudo bash /opt/omnara3/deploy.sh
```

部署脚本会交互式询问：

1. **域名**（如 `api.example.com`）
2. **Omnara Token**（从 https://app.omnara.com → 侧边栏 API Tokens → New token 获取，只显示一次）

自动生成随机 `GATEWAY_API_KEY`（客户端连接用的 Key），存在 `/opt/omnara3/.env`。

## 手动部署（不用脚本）

```bash
cd /opt/omnara3
cp .env.example .env
# 编辑 .env 填入 OMNARA_TOKEN 和 GATEWAY_API_KEY
docker compose up -d --build
```

部署后本地地址：`http://127.0.0.1:8787/v1`（若用 `HOST_PORT` 指定了其他端口则为该端口；容器内端口固定 8787）

## 配置说明（.env）

| 变量 | 必填 | 说明 |
|---|---|---|
| `OMNARA_TOKEN` | ✅ | Omnara API Token，多个用英文逗号分隔：`key1,key2` |
| `GATEWAY_API_KEY` | ✅ | 客户端连接密码，部署脚本自动生成 |
| `OMNARA_ORG_ID` | 可选 | 固定组织 ID，留空自动选第一个 |
| `OMNARA_PROJECT_ID` | 可选 | 固定项目 ID |
| `OMNARA_MODEL_PROVIDER` | 可选 | 固定模型 provider（用于无名字请求的默认模型） |
| `OMNARA_MODEL_NAME` | 可选 | 固定模型名（需完整名，如 `google/gemini-3.1-pro-preview`） |
| `STATELESS_MODE` | 可选 | `true`（默认）无状态模式，每次新 Agent |
| `FAKE_STREAM` | 可选 | `true` 时先收完再模拟流式输出，防长连接断开 |
| `MACHINE_CLEANUP_ENABLED` | 可选 | `true`（默认）自动清理残留沙箱机器 |
| `MACHINE_CLEANUP_INTERVAL_SECONDS` | 可选 | 清理扫描间隔，默认 900 秒 |
| `MACHINE_IDLE_DELETE_MINUTES` | 可选 | 池闲置自动删除阈值，默认 5 分钟 |

## ⚠️ 模型名必须填完整名

Omnara 平台自己只认完整模型名（实测：传 `GPT-5` → 400 拒绝，传 `anthropic/claude-opus-5.5` → 201 成功）。本网关透传模型名，**客户端（酒馆等）里模型名必须填完整全名**：

| ❌ 会报错 | ✅ 正确 |
|---|---|
| `GPT-5` | `openai/gpt-5.x`（以 /v1/models 实际清单为准） |
| `opus-5.5` | `anthropic/claude-opus-5.5` |
| `gemini-3.1-pro` | `google/gemini-3.1-pro-preview` |
| `claude` / `gemini` / 裸词 | 一律报错 |

**查询当前账号可用模型完整名**：

```bash
curl -s -H "Authorization: Bearer 你的GATEWAY_API_KEY" \
  https://你的域名/v1/models | python3 -m json.tool
```

填错名字时网关会返回中文报错并附完整可用模型清单，例如：
`模型 'GPT-5' 在当前账号未被授权。可用模型: xiaomi/mimo-v2.6-flash, anthropic/claude-opus-5.5, ...`

模型名留空或填 `omnara` / `default` 时，使用 `.env` 里 `OMNARA_MODEL_PROVIDER`/`OMNARA_MODEL_NAME` 指定的默认模型；都没配置则回落到该账号授权列表的第一个模型。

## 客户端配置（酒馆 / SillyTavern）

| 字段 | 值 |
|---|---|
| API 类型 | OpenAI 兼容 / Chat Completion |
| API 地址 | `https://你的域名/v1` |
| API Key | `.env` 里的 `GATEWAY_API_KEY` |
| 模型 | **完整模型名**（用上面的 `/v1/models` 查），或 `omnara` 用默认 |

## 管理端点

需请求头 `Authorization: Bearer <GATEWAY_API_KEY>`：

| 端点 | 方法 | 说明 |
|---|---|---|
| `/health` | GET | 健康检查 + Token 池状态 + 默认账号模型清单 |
| `/v1/models` | GET | 可用模型完整名清单 |
| `/admin/machines` | GET | 列出所有 Token 各自 org 的机器和池 |
| `/admin/machines/cleanup` | POST | 手动立即触发一轮机器清理 |
| `/admin/usage` | GET | 汇总所有账号的模型 token 用量与官方成本（provider_reported_usd） |

示例——查用量：

```bash
curl -s -H "Authorization: Bearer 你的GATEWAY_API_KEY" \
  https://你的域名/admin/usage | python3 -m json.tool
```

## 费用控制

Omnara 计费仅两项：

| 项目 | 费率 | 说明 |
|---|---|---|
| 模型 token | 提供商原价 | 无加价，以 `/admin/usage` 的 provider_reported_usd 为准 |
| 沙箱机器 | $0.0414/GiB/小时在线 + $0.20016/GiB/30天保留 | sleep 暂停运行时费，保留费照收；删除全停 |

本网关的清理机制：

- 后台每 15 分钟（默认 900 秒）扫描删除残留机器
- 每个 Token 各自 org 的池闲置自动删除阈值压到 5 分钟（API 最小值）
- **BYO（自有）机器永不触碰**——只清理池机器

## 常用运维命令

```bash
cd /opt/omnara3
docker compose ps                      # 状态
docker compose logs -f --tail=100      # 日志
docker compose up -d --build --force-recreate   # 改 .env 后重建
curl -s http://127.0.0.1:8787/healthz  # 本地健康检查（端口按你的 HOST_PORT）
```

注意：`docker compose down` 不会重载 `.env`，改配置后必须用 `up -d --force-recreate`。

## 安全说明

- 网关默认强制要求 `GATEWAY_API_KEY`（`REQUIRE_GATEWAY_API_KEY=true`），生产环境不要裸奔
- `.env` 权限 0600，含 Omnara Token 与网关 Key，**不要提交到 git / 不要外发**
- 容器以非 root 运行、`read_only` 文件系统、`cap_drop: ALL`
- 详见 `SECURITY_AUDIT.md`

## 技术栈

Python 3.12 / FastAPI / httpx / SQLite (aiosqlite) / Docker Compose / nginx

## License

Apache 2.0