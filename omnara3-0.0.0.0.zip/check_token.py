from __future__ import annotations

import asyncio
import sys
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

from app.config import Settings  # noqa: E402
from app.omnara import OmnaraClient, OmnaraError, TokenPool, inspect_account, mask_token  # noqa: E402


def _print(line: str = "") -> None:
    print(line, flush=True)


async def main() -> int:
    settings = Settings()
    token = settings.omnara_token.strip()
    if not token:
        _print("没有读到 OMNARA_TOKEN。")
        _print("1. 打开 https://app.omnara.com")
        _print("2. 侧边栏 API Tokens → New token")
        _print("3. 复制 .env.example 为 .env，把 Token 贴到 OMNARA_TOKEN=")
        return 1

    _print(f"API     : {settings.api_base}")
    _print(f"Token   : {mask_token(token)}")
    _print()

    # 兼容多 Token 配置：逐个探测，输出每个 Token 的账号信息
    pool = TokenPool(token)
    client = OmnaraClient(settings.api_base, pool)
    try:
        for i, tk in enumerate(pool.tokens(), 1):
            from app.omnara import pinned_token
            with pinned_token(tk):
                try:
                    account = await inspect_account(
                        client,
                        org_id=settings.omnara_org_id.strip(),
                        project_id=settings.omnara_project_id.strip(),
                    )
                except OmnaraError as exc:
                    _print(f"[{i}/{pool.count}] Token {mask_token(tk)} 校验失败 "
                           f"({exc.status_code or '?'} {exc.code}): {exc}")
                    continue

            if pool.count > 1:
                _print(f"── Token [{i}/{pool.count}] {mask_token(tk)} ──")
            if account.user_email or account.user_name:
                _print(f"用户    : {account.user_name} <{account.user_email}>")
            _print(f"类型    : {account.token_kind}")
            _print(f"组织    : {account.org_name}  ({account.org_id})")
            if len(account.orgs) > 1:
                _print("        这个账号有多个组织，建议在 .env 写死 OMNARA_ORG_ID。")
                for org in account.orgs:
                    _print(f"        - {org.get('name')}  ({org.get('id')})")
            _print(f"项目    : {account.project_name}  ({account.project_id})")
            if len(account.projects) > 1:
                _print("        这个组织有多个项目，建议在 .env 写死 OMNARA_PROJECT_ID。")
                for project in account.projects:
                    _print(f"        - {project.get('name')}  ({project.get('id')})")

            _print()
            if not account.models:
                _print("这个项目还没有已授权模型。Token 能用，但还不能聊天。")
                _print("到 https://app.omnara.com ：")
                _print("  Models → New provider → 粘贴你自己的 OpenAI/Anthropic/OpenRouter Key")
                _print("  添加模型 → Grant to project")
                _print("Omnara 自己不卖模型额度，模型 Key 存在它控制台，不用写进这个 .env。")
                continue

            _print("可用模型：")
            for model in account.models:
                _print(f"  - provider={model.provider_config!r}  name={model.name!r}")

            default = account.models[0]
            _print()
            _print("建议写入 .env 的字段（单 Token 时适用）：")
            _print(f"OMNARA_ORG_ID={account.org_id}")
            _print(f"OMNARA_PROJECT_ID={account.project_id}")
            _print(f"OMNARA_MODEL_PROVIDER={default.provider_config}")
            _print(f"OMNARA_MODEL_NAME={default.name}")
            _print()
        return 0
    finally:
        await client.aclose()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
