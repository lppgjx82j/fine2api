#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/omnara3"
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

die()  { echo "[FAIL] $*" >&2; exit 1; }
info() { echo "[INFO] $*"; }
ok()   { echo "[ OK ] $*"; }

[[ "${EUID}" -eq 0 ]] || die "请用 root 运行：sudo bash deploy.sh"
command -v docker >/dev/null || die "未找到 Docker"
docker compose version >/dev/null 2>&1 || die "未找到 Docker Compose v2 插件"

# 宿主端口：环境变量 HOST_PORT 优先，默认 8787。
# 若本机 8787 已被其他项目占用，改成空闲端口，例如：
#   HOST_PORT=38218 sudo bash deploy.sh
HOST_PORT="${HOST_PORT:-8787}"
info "宿主端口：${HOST_PORT}（容器内端口固定 8787）"

# 域名：环境变量优先，否则交互输入
if [[ -z "${DOMAIN:-}" ]]; then
    echo "请输入你的域名（如 api.example.com）："
    read -r DOMAIN
    [[ -n "${DOMAIN}" ]] || die "域名不能为空"
fi
info "域名：${DOMAIN}"

install -d -m 0750 "${APP_DIR}"
tar -C "${SOURCE_DIR}" \
    --exclude='./.env' \
    --exclude='./data' \
    --exclude='./.git' \
    -cf - . | tar -C "${APP_DIR}" -xf -
install -d -m 0750 "${APP_DIR}/data"

# 把 compose 的宿主端口替换为 ${HOST_PORT}（容器内端口始终 8787）
sed -i "s|127.0.0.1:[0-9]*:8787|127.0.0.1:${HOST_PORT}:8787|" "${APP_DIR}/docker-compose.yml"
# nginx 模板的反代端口同步替换为 ${HOST_PORT}
sed -i "s|proxy_pass http://127.0.0.1:[0-9]*;|proxy_pass http://127.0.0.1:${HOST_PORT};|" \
    "${APP_DIR}/nginx/your-domain.com.conf"

# .env 初始化
if [[ ! -f "${APP_DIR}/.env" ]]; then
    cp "${APP_DIR}/.env.example" "${APP_DIR}/.env"
    chmod 0600 "${APP_DIR}/.env"
    echo "请输入 Omnara API Token（输入时不回显）："
    read -r -s token
    echo
    [[ -n "${token}" ]] || die "OMNARA_TOKEN 不能为空"
    gateway_key="$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
    escaped="$(printf '%s' "${token}" | sed 's/[\/&|\\]/\\&/g')"
    sed -i "s|^OMNARA_TOKEN=.*|OMNARA_TOKEN=${escaped}|" "${APP_DIR}/.env"
    sed -i "s|^GATEWAY_API_KEY=.*|GATEWAY_API_KEY=${gateway_key}|" "${APP_DIR}/.env"
    unset token escaped gateway_key
    ok "已生成 .env（GATEWAY_API_KEY 随机生成）"
else
    chmod 0600 "${APP_DIR}/.env"
    info ".env 已存在，保留"
fi

grep -Eq '^OMNARA_TOKEN=[^[:space:]]' "${APP_DIR}/.env" || die ".env 缺少 OMNARA_TOKEN"
grep -Eq '^GATEWAY_API_KEY=[^[:space:]]' "${APP_DIR}/.env" || die ".env 缺少 GATEWAY_API_KEY"

# nginx 配置（可选）
if command -v nginx >/dev/null 2>&1; then
    # 替换 nginx 模板里的域名占位符
    NGINX_CONF="${APP_DIR}/nginx/${DOMAIN}.conf"
    sed "s|your-domain.com|${DOMAIN}|g" "${APP_DIR}/nginx/your-domain.com.conf" > "${NGINX_CONF}"
    
    # 检测证书路径
    CERT_BASE="$(echo "${DOMAIN}" | rev | cut -d. -f1-2 | rev)"
    CERT_DIR="/etc/letsencrypt/live/${CERT_BASE}"
    if [[ -d "${CERT_DIR}" ]]; then
        sed -i "s|/etc/letsencrypt/live/your-domain.com|${CERT_DIR}|g" "${NGINX_CONF}"
        info "使用通配符证书：${CERT_DIR}"
    else
        info "未找到 ${CERT_DIR}，请自行配置 SSL 证书路径"
    fi
    
    install -m 0644 "${NGINX_CONF}" "/etc/nginx/sites-available/${DOMAIN}.conf"
    ln -sfn "/etc/nginx/sites-available/${DOMAIN}.conf" "/etc/nginx/sites-enabled/${DOMAIN}.conf"
    nginx -t && systemctl reload nginx
    ok "nginx 已配置并重载"
else
    info "未检测到 nginx，跳过（可手动配置反向代理）"
fi

# 构建启动
cd "${APP_DIR}"
docker compose up -d --build

echo
echo "=============================================="
echo "  omnara3 部署完成"
echo "=============================================="
echo "  本地地址: http://127.0.0.1:${HOST_PORT}/v1"
echo "  域名:     https://${DOMAIN}/v1"
echo "  目录:     ${APP_DIR}"
echo "  状态:     cd ${APP_DIR} && docker compose ps"
echo "  日志:     cd ${APP_DIR} && docker compose logs -f --tail=100"
echo "  API Key:  查看 ${APP_DIR}/.env 中 GATEWAY_API_KEY"
echo "=============================================="
