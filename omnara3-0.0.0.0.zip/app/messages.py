from __future__ import annotations

import hashlib
import re
from typing import Any

def _as_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        chunks: list[str] = []
        for part in content:
            if isinstance(part, str):
                chunks.append(part)
                continue
            if not isinstance(part, dict):
                continue
            part_type = str(part.get("type") or "")
            if part_type in {"text", "input_text"} or "text" in part:
                text = part.get("text")
                if isinstance(text, dict):
                    text = text.get("value") or text.get("text")
                if text:
                    chunks.append(str(text))
        return "\n".join(chunk for chunk in chunks if chunk)
    return str(content)


def extract_system_prompt(messages: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    for message in messages:
        role = str(message.get("role") or "").lower()
        if role in {"system", "developer"}:
            text = _as_text(message.get("content")).strip()
            if text:
                parts.append(text)
    return "\n\n".join(parts).strip()


def first_user_text(messages: list[dict[str, Any]]) -> str:
    for message in messages:
        if str(message.get("role") or "").lower() == "user":
            return _as_text(message.get("content")).strip()
    return ""


def last_user_message(messages: list[dict[str, Any]]) -> dict[str, Any] | None:
    for message in reversed(messages):
        if str(message.get("role") or "").lower() == "user":
            return message
    return None


def last_user_text(messages: list[dict[str, Any]]) -> str:
    message = last_user_message(messages)
    if message is None:
        return ""
    return _as_text(message.get("content")).strip()


def user_content_blocks(message: dict[str, Any]) -> list[dict[str, Any]]:
    content = message.get("content")
    blocks: list[dict[str, Any]] = []
    texts: list[str] = []

    def add_text(value: str) -> None:
        value = value.strip()
        if value:
            texts.append(value)

    def add_image(url: str, filename: str = "image") -> None:
        mime, data = _parse_data_url(url)
        if mime and data:
            blocks.append(
                {
                    "type": "media",
                    "media_type": mime,
                    "filename": f"{filename}.{mime.split('/', 1)[1]}",
                    "data": data,
                }
            )

    if isinstance(content, str):
        add_text(content)
    elif isinstance(content, list):
        for index, part in enumerate(content):
            if isinstance(part, str):
                add_text(part)
                continue
            if not isinstance(part, dict):
                continue
            part_type = str(part.get("type") or "")
            if part_type in {"text", "input_text"} or part.get("text"):
                text = part.get("text")
                if isinstance(text, dict):
                    text = text.get("value") or text.get("text")
                add_text(str(text or ""))
            elif part_type in {"image_url", "image"} or part.get("image_url"):
                image = part.get("image_url")
                url = image.get("url") if isinstance(image, dict) else part.get("url")
                if isinstance(url, str):
                    add_image(url, filename=f"image{index + 1}")

    if texts:
        blocks.insert(0, {"type": "text", "text": "\n".join(texts)})
    return blocks


def _parse_data_url(url: str) -> tuple[str, str]:
    match = re.match(r"^data:(image/(?:png|jpeg|jpg|gif|webp));base64,(.+)$", url, re.I)
    if not match:
        return "", ""
    mime = match.group(1).lower()
    if mime == "image/jpg":
        mime = "image/jpeg"
    return mime, match.group(2)


def session_fingerprint(
    messages: list[dict[str, Any]],
    *,
    explicit: str = "",
) -> str:
    if explicit.strip():
        return explicit.strip()[:200]
    system = extract_system_prompt(messages)
    first_user = first_user_text(messages)
    raw = f"{system}\n---\n{first_user}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def instruction_hash(instruction: str) -> str:
    return hashlib.sha256(instruction.encode("utf-8")).hexdigest()


def build_full_context_instruction(messages: list[dict[str, Any]]) -> tuple[str, str]:
    """
    把酒馆发来的完整 messages 数组序列化为 Omnara Agent 的 instruction 字符串。

    返回 (instruction, last_user_text):
      - instruction: system prompt + 除最后一条 user 消息之外的所有对话历史
      - last_user_text: 最后一条 user 消息的纯文本（用于 send_input）

    这样每次创建的 Agent 都携带了完整上下文，实现无状态模式。
    """
    system = extract_system_prompt(messages)
    # 收集非 system/developer 的对话消息
    conversation: list[dict[str, Any]] = []
    for msg in messages:
        role = str(msg.get("role") or "").lower()
        if role not in {"system", "developer"}:
            conversation.append(msg)

    if not conversation:
        return system or "You are a helpful assistant.", ""

    # 最后一条 user 消息单独提取（将通过 send_input 发送）
    last_user = ""
    history = conversation
    if str(conversation[-1].get("role") or "").lower() == "user":
        last_user = _as_text(conversation[-1].get("content")).strip()
        history = conversation[:-1]

    # 把对话历史序列化为 instruction 的一部分
    parts: list[str] = []
    if system:
        parts.append(system)

    if history:
        parts.append("\n<conversation_history>")
        for msg in history:
            role = str(msg.get("role") or "").lower()
            text = _as_text(msg.get("content")).strip()
            if not text:
                continue
            if role == "assistant":
                parts.append(f"[Assistant]: {text}")
            elif role == "user":
                parts.append(f"[User]: {text}")
            else:
                parts.append(f"[{role.capitalize()}]: {text}")
        parts.append("</conversation_history>")
        parts.append(
            "\nContinue the conversation naturally based on the history above. "
            "The user's next message will follow."
        )

    instruction = "\n\n".join(parts)
    return instruction, last_user
