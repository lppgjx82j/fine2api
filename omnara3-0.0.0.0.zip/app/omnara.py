from __future__ import annotations

import json
import logging
import threading
import time
from collections.abc import AsyncIterator
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger("omnara")


class OmnaraError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str = "",
        payload: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.payload = payload


class TokenExhaustedError(OmnaraError):
    """所有 Token 额度均已耗尽。"""
    pass


# 请求级 Token 锁定：一轮对话内所有 API 调用使用同一个 Token。
# 使用 ContextVar 保证并发请求之间互不干扰（asyncio 安全）。
_pinned_token: ContextVar[str | None] = ContextVar("_pinned_token", default=None)


class pinned_token:
    """上下文管理器：在 with 块内锁定某个 Token，块内所有请求都使用它。"""

    def __init__(self, token: str) -> None:
        self._token = token
        self._prev: Any = None

    def __enter__(self) -> str:
        self._prev = _pinned_token.set(self._token)
        return self._token

    def __exit__(self, *exc: Any) -> None:
        _pinned_token.reset(self._prev)


@dataclass(frozen=True)
class ResolvedModel:
    provider_config: str
    name: str
    slug: str = ""
    configured_model_id: str = ""


@dataclass
class AccountSnapshot:
    token_kind: str
    user_email: str
    user_name: str
    org_id: str
    org_name: str
    project_id: str
    project_name: str
    models: list[ResolvedModel]
    orgs: list[dict[str, Any]]
    projects: list[dict[str, Any]]


def mask_token(token: str) -> str:
    token = token.strip()
    if len(token) <= 10:
        return "***"
    return f"{token[:14]}…{token[-4:]}"


def token_kind(token: str) -> str:
    if token.startswith("omnara_org_v1_"):
        return "organization"
    if token.startswith("omnara_pat_v1_"):
        return "personal"
    if token.startswith("omnara_"):
        return "omnara"
    return "unknown"


# Token 被标记为不可用后的冷却时间（秒），超过后会重新尝试
_TOKEN_COOLDOWN = 300


class TokenPool:
    """
    管理多个 Omnara Token 的轮换池。

    支持逗号分隔的多 Token 配置。当某个 Token 触发 429（额度耗尽）
    或 401/403（无效/吊销）时，自动标记为不可用并切换到下一个。
    经过冷却期后会重新尝试被标记的 Token（额度可能已重置）。
    """

    def __init__(self, tokens_str: str) -> None:
        raw = [t.strip() for t in tokens_str.split(",") if t.strip()]
        if not raw:
            raise OmnaraError("未配置 OMNARA_TOKEN。")
        self._tokens: list[str] = raw
        # {token: 被标记为不可用的时间戳}，不在此 dict 中表示可用
        self._disabled: dict[str, float] = {}
        self._index = 0  # 当前轮询位置
        self._lock = threading.Lock()

    @property
    def count(self) -> int:
        return len(self._tokens)

    def tokens(self) -> list[str]:
        """返回所有 Token 列表（含被禁用的，用于启动探测）。"""
        return list(self._tokens)

    @property
    def first(self) -> str:
        """返回第一个 Token，用于启动时的 inspect_account 校验。"""
        return self._tokens[0]

    def get(self) -> str:
        """
        获取当前可用的 Token。按轮询顺序查找，跳过冷却中的 Token。
        如果所有 Token 都不可用，抛出 TokenExhaustedError。
        """
        now = time.time()
        with self._lock:
            # 先清理已过冷却期的 Token
            expired = [t for t, ts in self._disabled.items() if now - ts >= _TOKEN_COOLDOWN]
            for t in expired:
                logger.info("[token-pool] Token %s 冷却结束，重新启用", mask_token(t))
                del self._disabled[t]

            # 从当前位置开始，找第一个可用的
            n = len(self._tokens)
            for i in range(n):
                idx = (self._index + i) % n
                candidate = self._tokens[idx]
                if candidate not in self._disabled:
                    self._index = (idx + 1) % n  # 下次从下一个开始
                    return candidate

            raise TokenExhaustedError(
                f"所有 {n} 个 Omnara Token 额度均已耗尽或不可用，请稍后再试。",
                status_code=429,
            )

    def mark_bad(self, token: str, reason: str = "") -> None:
        """将某个 Token 标记为不可用（进入冷却期）。"""
        with self._lock:
            if token in self._disabled:
                return
            self._disabled[token] = time.time()
            avail = len(self._tokens) - len(self._disabled)
            logger.warning(
                "[token-pool] Token %s 被标记不可用（%s），剩余可用 %d/%d",
                mask_token(token), reason, avail, len(self._tokens),
            )

    def ensure_usable(self, token: str) -> bool:
        """
        强制恢复某个 Token 为可用（若在冷却期则立即解除）。

        用途：有状态模式下会话与 Token 绑定。即使该 Token 短暂冷却，
        也优先用它维持会话上下文连续性，避免换号导致 Agent 重建、记忆丢失。
        返回 True 表示该 Token 原本处于冷却期、已被解除。
        """
        with self._lock:
            removed = self._disabled.pop(token, None)
        if removed is not None:
            logger.info(
                "[token-pool] Token %s 冷却提前解除（有状态会话绑定）", mask_token(token)
            )
        return removed is not None

    def is_available(self, token: str) -> bool:
        """检查某个 Token 当前是否可用（不在冷却期）。"""
        now = time.time()
        with self._lock:
            ts = self._disabled.get(token)
            return ts is None or now - ts >= _TOKEN_COOLDOWN

    def status(self) -> list[dict[str, Any]]:
        """返回所有 Token 的状态信息。"""
        now = time.time()
        result = []
        with self._lock:
            for t in self._tokens:
                disabled_at = self._disabled.get(t)
                if disabled_at is None:
                    result.append({"token": mask_token(t), "status": "available"})
                else:
                    remaining = max(0, _TOKEN_COOLDOWN - (now - disabled_at))
                    result.append({
                        "token": mask_token(t),
                        "status": "cooldown",
                        "cooldown_remaining_s": int(remaining),
                    })
        return result


class OmnaraClient:
    def __init__(self, base_url: str, token_pool: TokenPool, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token_pool = token_pool
        self._timeout = timeout
        # httpx.AsyncClient 不再写死 Authorization header，每次请求动态注入
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Accept": "application/json"},
            timeout=httpx.Timeout(timeout, connect=15.0),
        )

    @property
    def token(self) -> str:
        """兼容旧代码引用（如 inspect_account 里的 token_kind(client.token)）。"""
        return self.token_pool.first

    def _auth_headers(self, token: str | None = None) -> dict[str, str]:
        """生成带有当前 Token 的认证 header。"""
        t = token or self.token_pool.get()
        return {"Authorization": f"Bearer {t}"}

    async def aclose(self) -> None:
        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Any:
        current_token = _pinned_token.get() or self.token_pool.get()
        auth = {"Authorization": f"Bearer {current_token}"}
        merged = {**auth, **(headers or {})}
        try:
            response = await self._client.request(
                method,
                path,
                params=params,
                json=json_body,
                headers=merged,
                timeout=timeout,
            )
        except httpx.HTTPError as exc:
            raise OmnaraError(f"Omnara 网络错误: {exc}") from exc

        # 401/403/429：Token 无效或额度耗尽 → 标记并尝试下一个 Token 重试
        # 404：当前 Token 无权访问目标 org/project（多账号 Token 池的典型现象）→ 同样切换
        if response.status_code in {401, 403, 429, 404} and _pinned_token.get() is None:
            reason_map = {
                401: "无效/已撤销",
                403: "无权限",
                404: "无权访问该组织/项目",
                429: "额度耗尽",
            }
            reason = f"HTTP {response.status_code} {reason_map[response.status_code]}"
            logger.warning("[token-pool] Token %s 失败（%s），尝试切换", mask_token(current_token), reason)
            self.token_pool.mark_bad(current_token, reason=reason)
            try:
                next_token = self.token_pool.get()
            except TokenExhaustedError:
                pass
            else:
                retry_auth = {"Authorization": f"Bearer {next_token}"}
                retry_merged = {**retry_auth, **(headers or {})}
                try:
                    response = await self._client.request(
                        method, path, params=params, json=json_body,
                        headers=retry_merged, timeout=timeout,
                    )
                except httpx.HTTPError as exc:
                    raise OmnaraError(f"Omnara 网络错误: {exc}") from exc
                if response.status_code in {401, 403, 429}:
                    self.token_pool.mark_bad(next_token, reason=f"HTTP {response.status_code}")

        if response.status_code >= 400:
            payload: Any
            try:
                payload = response.json()
            except ValueError:
                payload = {"error": response.text}
            message = ""
            code = ""
            if isinstance(payload, dict):
                message = str(payload.get("error") or payload.get("message") or "")
                code = str(payload.get("code") or "")
            if not message:
                message = response.text or f"HTTP {response.status_code}"
            raise OmnaraError(
                message,
                status_code=response.status_code,
                code=code,
                payload=payload,
            )
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    async def get(self, path: str, **kwargs: Any) -> Any:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> Any:
        return await self.request("POST", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> Any:
        return await self.request("PUT", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> Any:
        return await self.request("DELETE", path, **kwargs)

    async def list_all(self, path: str, params: dict[str, Any] | None = None) -> list[Any]:
        items: list[Any] = []
        cursor: str | None = None
        while True:
            query = dict(params or {})
            query.setdefault("limit", 100)
            if cursor:
                query["cursor"] = cursor
            page = await self.get(path, params=query)
            batch = page.get("data") if isinstance(page, dict) else None
            if not isinstance(batch, list):
                return items
            items.extend(batch)
            cursor = page.get("next_cursor")
            if not cursor:
                return items

    def agent_base(self, org_id: str, project_id: str, agent_id: str) -> str:
        return f"/orgs/{org_id}/projects/{project_id}/agents/{agent_id}"

    async def create_config(
        self,
        org_id: str,
        project_id: str,
        *,
        instruction: str,
        provider_config: str,
        model_name: str,
    ) -> dict[str, Any]:
        source = {
            "version": "v1",
            "instruction": instruction,
            "model": {
                "provider_config": provider_config,
                "name": model_name,
            },
        }
        return await self.post(
            f"/orgs/{org_id}/projects/{project_id}/agent-configs",
            json_body={"source": json.dumps(source, ensure_ascii=False), "source_format": "json"},
        )

    async def create_agent(
        self,
        org_id: str,
        project_id: str,
        *,
        config_id: str,
        name: str,
        message: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        headers = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key[:255]
        body: dict[str, Any] = {"config": config_id, "name": name}
        if message:
            body["message"] = message
        return await self.post(
            f"/orgs/{org_id}/projects/{project_id}/agents",
            json_body=body,
            headers=headers or None,
        )

    async def get_agent(self, org_id: str, project_id: str, agent_id: str) -> dict[str, Any]:
        return await self.get(self.agent_base(org_id, project_id, agent_id))

    async def send_input(
        self,
        org_id: str,
        project_id: str,
        agent_id: str,
        *,
        content_blocks: list[dict[str, Any]],
        delivery_mode: str = "queued",
        cancel_open_interactions: bool = False,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "content_blocks": content_blocks,
            "delivery_mode": delivery_mode,
        }
        if delivery_mode == "steering":
            body["cancel_open_interactions"] = cancel_open_interactions
        headers = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key[:255]
        return await self.post(
            f"{self.agent_base(org_id, project_id, agent_id)}/inputs",
            json_body=body,
            headers=headers or None,
        )

    async def cancel_agent(self, org_id: str, project_id: str, agent_id: str) -> Any:
        return await self.post(f"{self.agent_base(org_id, project_id, agent_id)}/cancel")

    async def archive_agent(self, org_id: str, project_id: str, agent_id: str) -> Any:
        """归档 Agent，释放服务端资源。在无状态模式下每次生成完毕后调用。"""
        try:
            return await self.post(f"{self.agent_base(org_id, project_id, agent_id)}/archive")
        except OmnaraError:
            # 归档失败不影响用户体验，静默忽略
            return None

    # ---------- 机器清理（费用止损）相关 API ----------

    async def list_pools(self, org_id: str) -> list[dict[str, Any]]:
        """列出该组织所有 machine pool（含 Omnara 托管的 default-pool）。"""
        payload = await self.get(f"/orgs/{org_id}/machine-pools", params={"limit": 100})
        data = payload.get("data") if isinstance(payload, dict) else None
        return data if isinstance(data, list) else []

    async def get_usage(self, org_id: str) -> dict[str, Any]:
        """查询该组织模型 token 用量与官方成本（provider_reported_usd）。"""
        return await self.get(f"/orgs/{org_id}/usage")

    async def update_pool_idle_policy(self, org_id: str, pool_id: str, minutes: int) -> Any:
        """设置池的闲置自动删除分钟数（集群管理的 default-pool 也允许改这个字段）。"""
        return await self.put(
            f"/orgs/{org_id}/machine-pools/{pool_id}",
            json_body={"delete_after_idle_minutes": max(5, int(minutes))},
        )

    async def list_machines(self, org_id: str) -> list[dict[str, Any]]:
        """列出该组织下所有可见机器（BYO + 池机器），含 connection_state。"""
        payload = await self.get(f"/orgs/{org_id}/machines", params={"limit": 100})
        data = payload.get("data") if isinstance(payload, dict) else None
        return data if isinstance(data, list) else []

    async def delete_byo_machine(self, org_id: str, machine_id: str) -> bool:
        """
        删除一台 BYO 机器（source_kind=byo）。
        返回 True 表示删除成功；404 视为已不存在，返回 False。
        池机器调用此路由会 404/409，由调用方保证不这么做。
        """
        try:
            await self.delete(f"/orgs/{org_id}/machines/{machine_id}")
            return True
        except OmnaraError as exc:
            if exc.status_code == 404:
                return False
            raise

    async def list_open_interactions(
        self, org_id: str, project_id: str, agent_id: str
    ) -> list[dict[str, Any]]:
        payload = await self.get(
            f"{self.agent_base(org_id, project_id, agent_id)}/interactions",
            params={"state": "open", "limit": 100},
        )
        data = payload.get("data") if isinstance(payload, dict) else None
        return data if isinstance(data, list) else []

    async def get_events(
        self,
        org_id: str,
        project_id: str,
        agent_id: str,
        *,
        after_sequence: int = 0,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if after_sequence > 0:
            params["after_sequence"] = after_sequence
        try:
            payload = await self.get(
                f"{self.agent_base(org_id, project_id, agent_id)}/events",
                params=params,
            )
            data = payload.get("data") if isinstance(payload, dict) else None
            return data if isinstance(data, list) else []
        except Exception:
            return []

    async def resolve_interaction(
        self,
        org_id: str,
        project_id: str,
        agent_id: str,
        interaction_id: str,
        answers: list[dict[str, Any]],
    ) -> Any:
        return await self.post(
            f"{self.agent_base(org_id, project_id, agent_id)}/interactions/{interaction_id}/resolve",
            json_body={"answers": answers},
        )

    async def stream_events(
        self,
        org_id: str,
        project_id: str,
        agent_id: str,
        *,
        after_sequence: int = 0,
        stream_deltas: bool = True,
    ) -> AsyncIterator[tuple[str, int | None, dict[str, Any]]]:
        params: dict[str, Any] = {"stream_deltas": str(stream_deltas).lower()}
        if after_sequence > 0:
            params["after_sequence"] = after_sequence
        try:
            # 遵守请求级 Token 锁定：一轮对话内流式监听也必须用同一个 Token
            current_token = _pinned_token.get() or self.token_pool.get()
            async with self._client.stream(
                "GET",
                f"{self.agent_base(org_id, project_id, agent_id)}/events/stream",
                params=params,
                headers={"Accept": "text/event-stream", "Authorization": f"Bearer {current_token}"},
                timeout=httpx.Timeout(None, connect=15.0),
            ) as response:
                if response.status_code >= 400:
                    raw = (await response.aread()).decode("utf-8", errors="replace")
                    raise OmnaraError(
                        raw or f"stream HTTP {response.status_code}",
                        status_code=response.status_code,
                    )
                async for event_name, event_id, data in _iter_sse(response):
                    if not data:
                        continue
                    try:
                        payload = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    seq: int | None = None
                    if event_id and event_id.isdigit():
                        seq = int(event_id)
                    elif isinstance(payload, dict) and isinstance(payload.get("sequence"), int):
                        seq = payload["sequence"]
                    yield event_name, seq, payload if isinstance(payload, dict) else {}
        except OmnaraError:
            # 业务错误（401/403/404 等）不能吞掉，必须向上抛
            raise
        except Exception:
            # 仅捕获网络级断连异常（incomplete chunked read / peer closed / ReadTimeout 等）
            # 静默退出当前流，由上层 bridge._run_turn 的 while True 循环带着 last_seen 自动重连
            return


async def _iter_sse(response: httpx.Response) -> AsyncIterator[tuple[str, str | None, str]]:
    event_name = "message"
    event_id: str | None = None
    data_lines: list[str] = []

    def flush() -> tuple[str, str | None, str] | None:
        nonlocal event_name, event_id, data_lines
        if not data_lines:
            event_name = "message"
            event_id = None
            return None
        payload = "\n".join(data_lines)
        item = (event_name, event_id, payload)
        event_name = "message"
        event_id = None
        data_lines = []
        return item

    async for raw_line in response.aiter_lines():
        line = raw_line.rstrip("\r")
        if line.startswith(":"):
            continue
        if line == "":
            item = flush()
            if item:
                yield item
            continue
        if line.startswith("event:"):
            event_name = line[6:].strip() or "message"
        elif line.startswith("id:"):
            event_id = line[3:].strip() or None
        elif line.startswith("data:"):
            data_lines.append(line[5:].lstrip())

    item = flush()
    if item:
        yield item


async def inspect_account(
    client: OmnaraClient,
    *,
    org_id: str = "",
    project_id: str = "",
) -> AccountSnapshot:
    me: dict[str, Any] | None = None
    user_email = ""
    user_name = ""
    orgs: list[dict[str, Any]] = []
    # 优先使用当前 pinned 的 Token 判定类型；多 Token 启动探测时逐个准确识别
    effective_token = _pinned_token.get() or client.token
    kind = token_kind(effective_token)
    try:
        me = await client.get("/me")
        user = me.get("user") or {}
        user_email = str(user.get("email") or "")
        user_name = str(user.get("display_name") or "")
        orgs = list(me.get("orgs") or [])
    except OmnaraError as exc:
        org_only = kind == "organization" or exc.status_code in {403, 404}
        if exc.status_code == 401 and not org_only:
            raise OmnaraError(
                "Token 无效或已撤销。请到 app.omnara.com → API Tokens 重新签发。",
                status_code=401,
                code=exc.code,
            ) from exc
        if not org_id:
            raise OmnaraError(
                "当前 Token 不能访问 /me（组织 Token 常见）。请在 .env 填写 OMNARA_ORG_ID。",
                status_code=exc.status_code,
                code=exc.code,
            ) from exc

    resolved_org = org_id or (orgs[0]["id"] if orgs else "")
    if not resolved_org:
        raise OmnaraError("这个账号下没有组织。先在 app.omnara.com 完成注册引导。")

    org_name = next((item.get("name") for item in orgs if item.get("id") == resolved_org), "")
    if not org_name:
        org_name = resolved_org

    projects = await client.list_all(f"/orgs/{resolved_org}/projects")
    resolved_project = project_id or (projects[0]["id"] if projects else "")
    if not resolved_project:
        raise OmnaraError("这个组织下没有项目。先在控制台创建一个 Project。")
    project_name = next(
        (item.get("name") for item in projects if item.get("id") == resolved_project),
        resolved_project,
    )

    grants = await client.list_all(
        f"/orgs/{resolved_org}/projects/{resolved_project}/model-grants"
    )
    models: list[ResolvedModel] = []
    for item in grants:
        model = item.get("model") if isinstance(item, dict) else None
        if not isinstance(model, dict):
            continue
        models.append(
            ResolvedModel(
                provider_config=str(model.get("provider_config") or ""),
                name=str(model.get("name") or ""),
                configured_model_id=str(model.get("id") or ""),
            )
        )

    return AccountSnapshot(
        token_kind=kind,
        user_email=user_email,
        user_name=user_name,
        org_id=resolved_org,
        org_name=str(org_name),
        project_id=resolved_project,
        project_name=str(project_name),
        models=models,
        orgs=orgs,
        projects=projects,
    )


def pick_model(
    models: list[ResolvedModel],
    *,
    requested: str = "",
    provider: str = "",
    name: str = "",
) -> ResolvedModel | None:
    """按请求名解析模型。找不到时返回 None，绝不回落到 models[0]。

    回落策略由调用方显式决定：
    - 请求名为空/"omnara"/"default" 且 None → 允许用当前列表第一个（用户没指定名字）
    - 请求名非空且 None → 必须报错，禁止静默换模型（曾导致 mimo 重定向）
    """
    if not models:
        return None

    def matches(model: ResolvedModel, needle: str) -> bool:
        needle = needle.strip().lower()
        if not needle:
            return False
        return needle in {
            model.name.lower(),
            model.slug.lower(),
            model.provider_config.lower(),
            f"{model.provider_config} - {model.slug}".lower(),
            f"{model.provider_config}/{model.name}".lower(),
        }

    requested = (requested or "").strip()
    provider = (provider or "").strip()
    name = (name or "").strip()

    if requested and requested not in {"omnara", "default"}:
        # 精确匹配（全等）：只认完整模型名，不匹配任何短名/子串/后缀。
        # 匹配不上就返回 None，调用方报错——绝不静默换模型。
        for model in models:
            if matches(model, requested):
                return model
        return None

    if provider and name:
        for model in models:
            if model.provider_config == provider and model.name == name:
                return model
    if name:
        for model in models:
            if model.name == name:
                return model
    if provider:
        for model in models:
            if model.provider_config == provider:
                return model
    return None
