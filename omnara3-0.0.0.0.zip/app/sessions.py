from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import aiosqlite


@dataclass
class Session:
    session_key: str
    org_id: str
    project_id: str
    agent_id: str
    config_id: str
    last_sequence: int
    instruction_hash: str
    model_name: str
    # 会话绑定的 Omnara Token：有状态模式下同一会话必须始终使用同一个 Token，
    # 否则多 Token 轮询会导致 org/project 不匹配、Agent 重建、对话记忆丢失。
    token: str = ""


class SessionStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._ready = False
        self._locks: dict[str, asyncio.Lock] = {}
        self._locks_guard = asyncio.Lock()

    async def setup(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    session_key TEXT PRIMARY KEY,
                    org_id TEXT NOT NULL,
                    project_id TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    config_id TEXT NOT NULL DEFAULT '',
                    last_sequence INTEGER NOT NULL DEFAULT 0,
                    instruction_hash TEXT NOT NULL DEFAULT '',
                    model_name TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            await db.commit()
            # 旧库迁移：补 token 列（幂等）
            cursor = await db.execute("PRAGMA table_info(sessions)")
            cols = {row[1] for row in await cursor.fetchall()}
            if "token" not in cols:
                await db.execute(
                    "ALTER TABLE sessions ADD COLUMN token TEXT NOT NULL DEFAULT ''"
                )
                await db.commit()
        self._ready = True

    async def lock_for(self, session_key: str) -> asyncio.Lock:
        async with self._locks_guard:
            lock = self._locks.get(session_key)
            if lock is None:
                lock = asyncio.Lock()
                self._locks[session_key] = lock
            return lock

    async def get(self, session_key: str) -> Session | None:
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT * FROM sessions WHERE session_key = ?",
                (session_key,),
            )
            row = await cursor.fetchone()
        if row is None:
            return None
        return Session(
            session_key=row["session_key"],
            org_id=row["org_id"],
            project_id=row["project_id"],
            agent_id=row["agent_id"],
            config_id=row["config_id"],
            last_sequence=int(row["last_sequence"] or 0),
            instruction_hash=row["instruction_hash"],
            model_name=row["model_name"],
            token=str(row["token"] or ""),
        )

    async def upsert(self, session: Session) -> None:
        now = datetime.now(timezone.utc).isoformat()
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO sessions (
                    session_key, org_id, project_id, agent_id, config_id,
                    last_sequence, instruction_hash, model_name, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(session_key) DO UPDATE SET
                    org_id = excluded.org_id,
                    project_id = excluded.project_id,
                    agent_id = excluded.agent_id,
                    config_id = excluded.config_id,
                    last_sequence = excluded.last_sequence,
                    instruction_hash = excluded.instruction_hash,
                    model_name = excluded.model_name,
                    updated_at = excluded.updated_at
                """,
                (
                    session.session_key,
                    session.org_id,
                    session.project_id,
                    session.agent_id,
                    session.config_id,
                    session.last_sequence,
                    session.instruction_hash,
                    session.model_name,
                    now,
                    now,
                ),
            )
            await db.commit()

    async def update_sequence(self, session_key: str, sequence: int) -> None:
        now = datetime.now(timezone.utc).isoformat()
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE sessions SET last_sequence = ?, updated_at = ? WHERE session_key = ?",
                (sequence, now, session_key),
            )
            await db.commit()

    async def delete(self, session_key: str) -> None:
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM sessions WHERE session_key = ?", (session_key,))
            await db.commit()
