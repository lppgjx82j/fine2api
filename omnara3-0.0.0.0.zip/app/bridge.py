from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any

from app.config import Settings
from app.messages import (
    build_full_context_instruction,
    extract_system_prompt,
    instruction_hash,
    last_user_message,
    last_user_text,
    user_content_blocks,
)
from app.omnara import (
    OmnaraClient,
    OmnaraError,
    ResolvedModel,
    TokenExhaustedError,
    pick_model,
    pinned_token,
)
from app.openai_fmt import chunk, completion_id, done, map_finish_reason, non_stream_response
from app.sessions import Session, SessionStore

logger = logging.getLogger("omnara")

TERMINAL_STOP = {"end_turn", "max_tokens", "refusal", "content_filter", "error"}

# 触发切换下一个 Token 的 HTTP 状态码
_TOKEN_SWITCH_CODES = {401, 403, 404, 429}


class Bridge:
    def __init__(
        self,
        settings: Settings,
        client: OmnaraClient,
        store: SessionStore,
        *,
        org_id: str,
        project_id: str,
        models: list[ResolvedModel],
        accounts: dict[str, Any] | None = None,
        settings_org: str = "",
        settings_project: str = "",
    ) -> None:
        self.settings = settings
        self.client = client
        self.store = store
        # 默认（首个 Token 的）账号上下文
        self.org_id = org_id
        self.project_id = project_id
        self.models = models
        # token -> AccountSnapshot 映射；运行时按锁定的 token 动态解析
        self.accounts: dict[str, Any] = accounts or {}
        self.settings_org = settings_org
        self.settings_project = settings_project

    def _context_for_token(self, token: str) -> tuple[str, str, list[ResolvedModel]]:
        """返回该 Token 对应的 (org_id, project_id, models)。"""
        acc = self.accounts.get(token)
        if acc is None:
            # 未探测过的 Token（如冷却后恢复），回退到默认账号上下文
            return self.org_id, self.project_id, self.models
        return acc.org_id, acc.project_id, acc.models

    def _resolve_for_token(
        self, token: str, requested: str, models: list[ResolvedModel]
    ) -> ResolvedModel:
        """按当前 Token 的授权列表解析模型，绝不静默回落。

        - 请求名为空/"omnara"/"default"：用该 Token 自己的 models[0]（用户没指定名字）
        - 请求名非空且匹配不上：直接报错，列出该 Token 的可用模型清单
        """
        if requested and requested not in {"omnara", "default"}:
            m = pick_model(
                models,
                requested=requested,
                provider=self.settings.omnara_model_provider,
                name=self.settings.omnara_model_name,
            )
            if m is None:
                names = ", ".join(item.name for item in models) or "（无）"
                raise OmnaraError(
                    f"模型 {requested!r} 在当前账号未被授权。可用模型: {names}"
                )
            return m
        # 未指定模型名：env 显式配置优先（用户设置的默认模型），
        # 其次该 Token 自己的 models[0]（用户没指定也不配置时的兜底）
        if self.settings.omnara_model_provider or self.settings.omnara_model_name:
            m = pick_model(
                models,
                provider=self.settings.omnara_model_provider,
                name=self.settings.omnara_model_name,
            )
            if m is not None:
                return m
        if not models:
            raise OmnaraError("当前账号没有已授权模型。")
        return models[0]

    def resolve_model(self, requested: str) -> ResolvedModel:
        """校验默认账号有可用模型，并为空名字提供默认显示。

        注意：模型名的匹配校验不在默认账号上下文做（每个 Token 的
        授权列表可能不同），由 _resolve_for_token 按当前 Token 上下文
        负责——名字匹配不上在那里直接报错，绝不静默换模型。
        """
        if not self.models:
            raise OmnaraError(
                "这个 Project 还没有任何已授权模型。到 app.omnara.com → Models "
                "添加 Provider、配置模型，再 Grant to project。"
            )
        m = pick_model(
            self.models,
            requested=requested,
            provider=self.settings.omnara_model_provider,
            name=self.settings.omnara_model_name,
        )
        return m or self.models[0]

    def iter_sse(
        self,
        *,
        session_key: str,
        messages: list[dict[str, Any]],
        requested_model: str,
    ) -> AsyncIterator[str]:
        if self.settings.fake_stream:
            return self._fake_stream(session_key, messages, requested_model)
        return self._stream(session_key, messages, requested_model)

    async def _fake_stream(
        self,
        session_key: str,
        messages: list[dict[str, Any]],
        requested_model: str,
    ) -> AsyncIterator[str]:
        """
        假流式：先通过内部 _stream 静默收集完整回复，
        再把完整文本拆成小块以极快速度通过 SSE 逐块吐出，
        避免长连接等待导致中途断连。
        """
        collected: list[str] = []
        reasoning: list[str] = []
        finish = "stop"
        model_name = requested_model or "omnara"
        cid = completion_id()
        created = int(time.time())

        # 阶段一：静默收集全部内容
        async for line in self._stream(session_key, messages, requested_model):
            if not line.startswith("data: ") or line.strip() == "data: [DONE]":
                continue
            payload = json.loads(line[6:])
            model_name = payload.get("model") or model_name
            cid = payload.get("id") or cid
            created = payload.get("created") or created
            choice = (payload.get("choices") or [{}])[0]
            delta = choice.get("delta") or {}
            if delta.get("content"):
                collected.append(delta["content"])
            if delta.get("reasoning_content"):
                reasoning.append(delta["reasoning_content"])
            if choice.get("finish_reason"):
                finish = choice["finish_reason"]

        # 阶段二：把收集到的完整文本拆块快速吐出
        full_text = "".join(collected)
        full_reasoning = "".join(reasoning)
        chunk_size = self.settings.fake_stream_chunk_size
        delay = self.settings.fake_stream_delay

        yield chunk(completion_id=cid, model=model_name, created=created, delta={"role": "assistant"})

        if full_reasoning and self.settings.include_reasoning:
            for i in range(0, len(full_reasoning), chunk_size):
                yield chunk(
                    completion_id=cid,
                    model=model_name,
                    created=created,
                    delta={"reasoning_content": full_reasoning[i:i + chunk_size]},
                )
                if delay > 0:
                    await asyncio.sleep(delay)

        if full_text:
            for i in range(0, len(full_text), chunk_size):
                yield chunk(
                    completion_id=cid,
                    model=model_name,
                    created=created,
                    delta={"content": full_text[i:i + chunk_size]},
                )
                if delay > 0:
                    await asyncio.sleep(delay)

        yield chunk(
            completion_id=cid,
            model=model_name,
            created=created,
            delta={},
            finish_reason=finish,
        )
        yield done()

    async def complete_json(
        self,
        *,
        session_key: str,
        messages: list[dict[str, Any]],
        requested_model: str,
    ) -> dict[str, Any]:
        collected: list[str] = []
        reasoning: list[str] = []
        finish = "stop"
        model_name = requested_model or "omnara"
        cid = completion_id()
        created = int(time.time())
        async for line in self._stream(session_key, messages, requested_model):
            if not line.startswith("data: ") or line.strip() == "data: [DONE]":
                continue
            payload = json.loads(line[6:])
            model_name = payload.get("model") or model_name
            cid = payload.get("id") or cid
            created = payload.get("created") or created
            choice = (payload.get("choices") or [{}])[0]
            delta = choice.get("delta") or {}
            if delta.get("content"):
                collected.append(delta["content"])
            if delta.get("reasoning_content"):
                reasoning.append(delta["reasoning_content"])
            if choice.get("finish_reason"):
                finish = choice["finish_reason"]
        return non_stream_response(
            completion_id=cid,
            model=model_name,
            created=created,
            content="".join(collected),
            reasoning="".join(reasoning),
            finish_reason=finish,
        )

    async def _stream(
        self,
        session_key: str,
        messages: list[dict[str, Any]],
        requested_model: str,
    ) -> AsyncIterator[str]:
        cid = completion_id()
        created = int(time.time())
        display_model = requested_model or "omnara"
        yielded_role = False

        def open_role() -> str:
            nonlocal yielded_role
            if yielded_role:
                return ""
            yielded_role = True
            return chunk(completion_id=cid, model=display_model, created=created, delta={"role": "assistant"})

        try:
            model = self.resolve_model(requested_model)
            display_model = requested_model or model.name

            if self.settings.stateless_mode:
                # --- 无状态模式：每次创建全新 Agent，完整上下文编入 instruction ---
                instruction, ctx_last_user = build_full_context_instruction(messages)
                if not ctx_last_user:
                    user_message = last_user_message(messages)
                    if user_message is None:
                        raise OmnaraError("请求里没有 user 消息。")
                    ctx_last_user = last_user_text(messages)
                    if not ctx_last_user and not user_content_blocks(user_message):
                        raise OmnaraError("最后一条 user 消息是空的。")
                    user_blocks = user_content_blocks(user_message) or [{"type": "text", "text": ctx_last_user}]
                else:
                    user_message = last_user_message(messages)
                    if user_message is not None:
                        user_blocks = user_content_blocks(user_message) or [{"type": "text", "text": ctx_last_user}]
                    else:
                        user_blocks = [{"type": "text", "text": ctx_last_user}]
            else:
                # --- 有状态模式（原逻辑）---
                user_message = last_user_message(messages)
                if user_message is None:
                    raise OmnaraError("请求里没有 user 消息。")
                ctx_last_user = last_user_text(messages)
                if not ctx_last_user and not user_content_blocks(user_message):
                    raise OmnaraError("最后一条 user 消息是空的。")
                instruction = extract_system_prompt(messages) or self.settings.default_instruction
                user_blocks = user_content_blocks(user_message) or [{"type": "text", "text": ctx_last_user}]
        except OmnaraError as exc:
            piece = open_role()
            if piece:
                yield piece
            yield chunk(
                completion_id=cid,
                model=display_model,
                created=created,
                delta={"content": f"\n[omnara] {exc}"},
            )
            yield chunk(
                completion_id=cid,
                model=display_model,
                created=created,
                delta={},
                finish_reason="stop",
            )
            yield done()
            return

        if self.settings.stateless_mode:
            # 无状态模式：整轮对话（创建Agent→发消息→监听→归档）锁定同一个 Token，
            # 并使用该 Token 自己的 org/project/models，避免跨账号 404。
            # 当前 Token 返回 401/403/404/429 时自动换下一个重试。
            total = max(1, self.client.token_pool.count)
            last_exc: Exception | None = None
            try:
                for attempt in range(total):
                    tk = self.client.token_pool.get()
                    org, proj, models = self._context_for_token(tk)
                    try:
                        # 按当前 Token 自己的授权列表解析；匹配不上直接报错，不回落
                        token_model = self._resolve_for_token(tk, requested_model, models)
                        with pinned_token(tk):
                            session = await self._create_fresh_agent(
                                org_id=org,
                                project_id=proj,
                                instruction=instruction,
                                model=token_model,
                                user_blocks=user_blocks,
                            )
                            async for piece in self._emit_turn(
                                session=session, cid=cid, display_model=display_model, open_role=open_role,
                            ):
                                yield piece
                            return
                    except OmnaraError as exc:
                        last_exc = exc
                        if exc.status_code in _TOKEN_SWITCH_CODES and attempt < total - 1:
                            # 标记该 Token 冷却，避免下个请求再次命中同一故障 Token
                            self.client.token_pool.mark_bad(tk, reason=f"HTTP {exc.status_code}")
                            logger.warning("[bridge] Token 尝试失败 (HTTP %s)，切换下一个", exc.status_code)
                            continue
                        break  # 不可切换的错误，跳出循环统一输出错误帧
            except TokenExhaustedError as exc:
                # 所有 Token 均处于冷却期
                last_exc = exc

            # 统一兜底：以 SSE 错误帧形式告知客户端，避免流式响应裸断连
            if last_exc is not None:
                piece = open_role()
                if piece:
                    yield piece
                yield chunk(
                    completion_id=cid,
                    model=display_model,
                    created=created,
                    delta={"content": f"\n[omnara] {last_exc}"},
                )
                yield chunk(
                    completion_id=cid,
                    model=display_model,
                    created=created,
                    delta={},
                    finish_reason="stop",
                )
                yield done()
            return

        # 有状态模式：走原有 session 复用逻辑。
        # 关键设计：会话与 Token 绑定 —— 同一会话始终使用创建它时的 Token，
        # 避免多 Token 轮询导致 org/project 不匹配、Agent 删建重建、对话记忆丢失。
        lock = await self.store.lock_for(session_key)
        async with lock:
            existing_session = await self.store.get(session_key)
            if existing_session is not None and existing_session.token:
                # 复用会话绑定的 Token；若其处于冷却期则强制解除
                #（保记忆连续性优先于额度轮换，失败后仍可正常切换）
                tk = existing_session.token
                self.client.token_pool.ensure_usable(tk)
            else:
                tk = self.client.token_pool.get()
            org, proj, models = self._context_for_token(tk)
            # 按当前 Token 自己的授权列表解析；匹配不上直接报错，不回落
            try:
                token_model = self._resolve_for_token(tk, requested_model, models)
            except OmnaraError as exc:
                # 模型名匹配不上：走统一错误帧，避免裸断连（与无状态分支一致）
                piece = open_role()
                if piece:
                    yield piece
                yield chunk(
                    completion_id=cid,
                    model=display_model,
                    created=created,
                    delta={"content": f"\n[omnara] {exc}"},
                )
                yield chunk(
                    completion_id=cid,
                    model=display_model,
                    created=created,
                    delta={},
                    finish_reason="stop",
                )
                yield done()
                return
            with pinned_token(tk):
                session = await self._ensure_agent(
                    session_key=session_key,
                    org_id=org,
                    project_id=proj,
                    instruction=instruction,
                    model=token_model,
                    user_message=user_message,
                    user_text=ctx_last_user,
                    token=tk,
                )
                async for piece in self._emit_turn(
                    session=session, cid=cid, display_model=display_model, open_role=open_role,
                ):
                    yield piece

    async def _emit_turn(
        self,
        *,
        session: Session,
        cid: str,
        display_model: str,
        open_role: Any,
    ) -> AsyncIterator[str]:
        """消费 _run_turn 并转换为 OpenAI SSE 帧；结束时按需归档 Agent。

        关键设计：Token 可切换类错误（401/403/404/429）不在此处吞掉，
        而是完成资源清理后原样向上抛出，让外层 _stream 的切换循环
        换下一个 Token 重试。只有不可切换的错误才就地转成 SSE 错误帧。
        """
        yielded_any = False
        try:
            async for kind, text in self._run_turn(session, timeout=self.settings.turn_timeout_seconds):
                if kind == "role":
                    piece = open_role()
                    if piece:
                        yield piece
                    continue
                if kind == "text":
                    yielded_any = True
                    piece = open_role()
                    if piece:
                        yield piece
                    yield chunk(
                        completion_id=cid,
                        model=display_model,
                        created=int(time.time()),
                        delta={"content": text},
                    )
                elif kind == "reasoning" and self.settings.include_reasoning:
                    yielded_any = True
                    piece = open_role()
                    if piece:
                        yield piece
                    yield chunk(
                        completion_id=cid,
                        model=display_model,
                        created=int(time.time()),
                        delta={"reasoning_content": text},
                    )
                elif kind == "status":
                    yield f": {text}\n\n"
                elif kind == "heartbeat":
                    yield ": heartbeat\n\n"
                elif kind == "finish":
                    piece = open_role()
                    if piece:
                        yield piece
                    yield chunk(
                        completion_id=cid,
                        model=display_model,
                        created=int(time.time()),
                        delta={},
                        finish_reason=text or "stop",
                    )
                    yield done()
                    if self.settings.stateless_mode:
                        await self.client.archive_agent(session.org_id, session.project_id, session.agent_id)
                    return
        except asyncio.CancelledError:
            try:
                await self.client.cancel_agent(session.org_id, session.project_id, session.agent_id)
            except OmnaraError:
                pass
            if self.settings.stateless_mode:
                await self.client.archive_agent(session.org_id, session.project_id, session.agent_id)
            raise
        except OmnaraError as exc:
            # 先做资源清理，再决定错误去向
            try:
                await self.client.cancel_agent(session.org_id, session.project_id, session.agent_id)
            except OmnaraError:
                pass
            if self.settings.stateless_mode:
                await self.client.archive_agent(session.org_id, session.project_id, session.agent_id)
            if (
                exc.status_code in _TOKEN_SWITCH_CODES
                and self.settings.stateless_mode
                and not yielded_any
            ):
                # 流式监听阶段早期（尚未向客户端输出任何正文）的 Token 故障：
                # 上抛给外层切换循环，换下一个 Token 完整重来。
                raise
            # 已输出过正文后出错：不能重试（会造成内容重复），就地转 SSE 错误帧收尾
            piece = open_role()
            if piece:
                yield piece
            yield chunk(
                completion_id=cid,
                model=display_model,
                created=int(time.time()),
                delta={"content": f"\n[omnara] {exc}"},
            )
            yield chunk(
                completion_id=cid,
                model=display_model,
                created=int(time.time()),
                delta={},
                finish_reason="stop",
            )
            yield done()
            return
        except Exception as exc:
            # 非 Omnara 异常（如超时包装、意外 bug）也要保证 SSE 正常收尾
            try:
                await self.client.cancel_agent(session.org_id, session.project_id, session.agent_id)
            except OmnaraError:
                pass
            if self.settings.stateless_mode:
                await self.client.archive_agent(session.org_id, session.project_id, session.agent_id)
            logger.exception("[bridge] 轮次处理发生意外异常")
            piece = open_role()
            if piece:
                yield piece
            yield chunk(
                completion_id=cid,
                model=display_model,
                created=int(time.time()),
                delta={"content": f"\n[omnara] {exc}"},
            )
            yield chunk(
                completion_id=cid,
                model=display_model,
                created=int(time.time()),
                delta={},
                finish_reason="stop",
            )
            yield done()
            return

        piece = open_role()
        if piece:
            yield piece
        yield chunk(
            completion_id=cid,
            model=display_model,
            created=int(time.time()),
            delta={},
            finish_reason="stop",
        )
        yield done()
        if self.settings.stateless_mode:
            await self.client.archive_agent(session.org_id, session.project_id, session.agent_id)

    async def _create_fresh_agent(
        self,
        *,
        org_id: str,
        project_id: str,
        instruction: str,
        model: ResolvedModel,
        user_blocks: list[dict[str, Any]],
    ) -> Session:
        """无状态模式专用：每次创建全新的 Config + Agent + 发送输入。
        任一步骤失败时归档已创建的 Agent，避免孤儿 Agent 泄漏额度。"""
        config = await self.client.create_config(
            org_id,
            project_id,
            instruction=instruction,
            provider_config=model.provider_config,
            model_name=model.name,
        )
        config_id = str(config.get("id") or "")
        if not config_id:
            raise OmnaraError("创建 Agent Config 成功，但响应里没有 id。")

        unique_key = uuid.uuid4().hex
        launched = await self.client.create_agent(
            org_id,
            project_id,
            config_id=config_id,
            name=f"st-{unique_key[:12]}",
            idempotency_key=f"ag-{unique_key}",
        )
        agent = launched.get("agent") or {}
        agent_id = str(agent.get("id") or "")
        if not agent_id:
            raise OmnaraError("创建 Agent 成功，但响应里没有 agent.id。")

        session = Session(
            session_key=unique_key,
            org_id=org_id,
            project_id=project_id,
            agent_id=agent_id,
            config_id=config_id,
            last_sequence=0,
            instruction_hash="",
            model_name=model.name,
        )

        try:
            await self.client.send_input(
                session.org_id,
                session.project_id,
                session.agent_id,
                content_blocks=user_blocks,
                delivery_mode="steering",
                cancel_open_interactions=True,
                idempotency_key=f"in-{uuid.uuid4().hex}",
            )
        except BaseException:
            # send_input 失败（如 404/429）：清理刚创建的孤儿 Agent 后再抛出
            await self.client.archive_agent(org_id, project_id, agent_id)
            raise
        return session

    async def _ensure_agent(
        self,
        *,
        session_key: str,
        org_id: str,
        project_id: str,
        instruction: str,
        model: ResolvedModel,
        user_message: dict[str, Any],
        user_text: str,
        token: str = "",
    ) -> Session:
        hashed = instruction_hash(instruction)
        existing = await self.store.get(session_key)
        if existing:
            alive = await self._agent_is_active(existing)
            same_setup = (
                existing.instruction_hash == hashed
                and existing.model_name == model.name
                and existing.org_id == org_id
                and existing.project_id == project_id
            )
            if alive and same_setup:
                await self._send_user_turn(existing, user_message, user_text)
                return existing
            await self.store.delete(session_key)

        config = await self.client.create_config(
            org_id,
            project_id,
            instruction=instruction,
            provider_config=model.provider_config,
            model_name=model.name,
        )
        config_id = str(config.get("id") or "")
        if not config_id:
            raise OmnaraError("创建 Agent Config 成功，但响应里没有 id。")

        launched = await self.client.create_agent(
            org_id,
            project_id,
            config_id=config_id,
            name=f"st-{session_key[:12]}",
            idempotency_key=f"ag-{session_key[:80]}-{uuid.uuid4().hex[:8]}",
        )
        agent = launched.get("agent") or {}
        agent_id = str(agent.get("id") or "")
        if not agent_id:
            raise OmnaraError("创建 Agent 成功，但响应里没有 agent.id。")

        session = Session(
            session_key=session_key,
            org_id=org_id,
            project_id=project_id,
            agent_id=agent_id,
            config_id=config_id,
            last_sequence=0,
            instruction_hash=hashed,
            model_name=model.name,
            token=token,
        )
        await self.store.upsert(session)
        await self._send_user_turn(session, user_message, user_text)
        return session

    async def _send_user_turn(
        self,
        session: Session,
        user_message: dict[str, Any],
        user_text: str,
    ) -> None:
        blocks = user_content_blocks(user_message) or [{"type": "text", "text": user_text}]
        await self.client.send_input(
            session.org_id,
            session.project_id,
            session.agent_id,
            content_blocks=blocks,
            delivery_mode="steering",
            cancel_open_interactions=True,
            idempotency_key=f"in-{uuid.uuid4().hex}",
        )

    async def _agent_is_active(self, session: Session) -> bool:
        try:
            payload = await self.client.get_agent(session.org_id, session.project_id, session.agent_id)
        except OmnaraError as exc:
            if exc.status_code in {404, 410}:
                return False
            raise
        agent = payload.get("agent") if isinstance(payload, dict) else None
        if not isinstance(agent, dict):
            return False
        return agent.get("state") == "active"

    async def _run_turn(
        self, session: Session, *, timeout: float
    ) -> AsyncIterator[tuple[str, str]]:
        deadline = time.monotonic() + timeout
        streamed_text_for_call: dict[str, str] = {}
        last_seen = session.last_sequence
        reconnect_delay = 0.5
        yield ("role", "")

        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise OmnaraError(f"等待 Omnara 回复超时（{int(timeout)}s）。")

            finished = False
            finish_reason = "stop"
            got_any_event = False
            async for event_name, seq, payload in self.client.stream_events(
                session.org_id,
                session.project_id,
                session.agent_id,
                after_sequence=last_seen,
                stream_deltas=True,
            ):
                got_any_event = True
                if time.monotonic() > deadline:
                    raise OmnaraError(f"等待 Omnara 回复超时（{int(timeout)}s）。")

                if seq and seq > last_seen:
                    last_seen = seq
                    session.last_sequence = seq
                    await self.store.update_sequence(session.session_key, seq)

                if event_name == "error":
                    raise OmnaraError(str(payload.get("error") or "Omnara 事件流返回 error"))

                if event_name == "model_output_delta":
                    async for item in self._handle_delta(payload, streamed_text_for_call):
                        yield item
                    continue

                if event_name == "tool_call_update":
                    state = str(payload.get("state") or "")
                    if state in {"awaiting_permission", "awaiting_authorization", "waiting"}:
                        yield ("status", f"auto-resolve {state}")
                        await self._auto_resolve(session)
                    continue

                if event_name == "model_output":
                    call_id = str(payload.get("model_call_context_id") or "")
                    already = streamed_text_for_call.get(call_id, "")
                    text = _blocks_text(payload.get("content_blocks") or [], kind="text")
                    if text.startswith(already):
                        extra = text[len(already) :]
                    elif already:
                        extra = ""
                    else:
                        extra = text
                    if extra:
                        yield ("text", extra)
                    streamed_text_for_call[call_id] = text
                    if self.settings.include_reasoning:
                        thinking = _blocks_text(payload.get("content_blocks") or [], kind="reasoning")
                        if thinking:
                            yield ("reasoning", thinking)
                    stop = str(payload.get("stop_reason") or "")
                    if stop == "tool_use":
                        await self._auto_resolve(session)
                        continue
                    if stop in TERMINAL_STOP:
                        finished = True
                        finish_reason = map_finish_reason(stop)
                        if stop == "error":
                            err = _blocks_text(payload.get("content_blocks") or [], kind="error")
                            if err:
                                yield ("text", f"\n[omnara error] {err}")
                        break
                    continue

                if event_name == "agent_input":
                    continue

            if finished:
                yield ("finish", finish_reason)
                return

            if time.monotonic() > deadline:
                raise OmnaraError(f"等待 Omnara 回复超时（{int(timeout)}s）。")

            # 渐进退避重连：收到过事件说明连接正常断开，重置；否则逐步增大间隔
            if got_any_event:
                reconnect_delay = 0.5
            else:
                reconnect_delay = min(reconnect_delay * 2, 5.0)

            # 在重连等待期间发送心跳，保持客户端 SSE 连接活跃
            wait_end = time.monotonic() + reconnect_delay
            while time.monotonic() < wait_end:
                yield ("heartbeat", "")
                await asyncio.sleep(min(3.0, wait_end - time.monotonic()))

    async def _handle_delta(
        self,
        payload: dict[str, Any],
        streamed_text_for_call: dict[str, str],
    ) -> AsyncIterator[tuple[str, str]]:
        event = payload.get("event") or {}
        kind = str(event.get("kind") or "")
        call_id = str(payload.get("model_call_context_id") or "")
        if kind == "text_delta":
            delta = str(event.get("delta") or "")
            if delta:
                streamed_text_for_call[call_id] = streamed_text_for_call.get(call_id, "") + delta
                yield ("text", delta)
        elif kind == "thinking_delta":
            delta = str(event.get("delta") or "")
            if delta:
                yield ("reasoning", delta)
        elif kind == "error":
            message = ""
            err = event.get("error")
            if isinstance(err, dict):
                message = str(err.get("message") or "")
            if message:
                yield ("text", f"\n[omnara error] {message}")

    async def _auto_resolve(self, session: Session) -> None:
        if not self.settings.auto_resolve_interactions:
            return
        try:
            opened = await self.client.list_open_interactions(
                session.org_id, session.project_id, session.agent_id
            )
        except OmnaraError:
            return
        for interaction in opened:
            interaction_id = str(interaction.get("id") or "")
            request = interaction.get("request") or {}
            questions = request.get("questions") or []
            answers = []
            for question in questions:
                options = question.get("options") or [{}]
                answers.append({"option_indices": [0 if options else 0]})
            if not answers:
                answers = [{"option_indices": [0]}]
            if interaction_id:
                try:
                    await self.client.resolve_interaction(
                        session.org_id,
                        session.project_id,
                        session.agent_id,
                        interaction_id,
                        answers,
                    )
                except OmnaraError:
                    continue


def _blocks_text(blocks: list[Any], *, kind: str) -> str:
    parts: list[str] = []
    for block in blocks:
        if not isinstance(block, dict):
            continue
        if block.get("type") == kind and block.get("text"):
            parts.append(str(block["text"]))
    return "".join(parts)