from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ROOT_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    omnara_api: str = "https://api.omnara.com/v1"
    omnara_token: str = ""
    omnara_org_id: str = ""
    omnara_project_id: str = ""
    omnara_model_provider: str = ""
    omnara_model_name: str = ""

    gateway_api_key: str = ""
    host: str = "0.0.0.0"
    port: int = 8787
    require_gateway_api_key: bool = True
    max_request_bytes: int = 52428800
    cors_origins: str = ""
    turn_timeout_seconds: float = 180
    auto_resolve_interactions: bool = True
    include_reasoning: bool = True
    fake_stream: bool = False
    fake_stream_chunk_size: int = 4
    fake_stream_delay: float = 0.02
    stateless_mode: bool = True
    session_db: str = "data/sessions.sqlite3"

    # 沙箱机器清理：删除残留的池机器以停止运行时/保留计费。
    # 仅影响池机器（default-pool 等）；BYO 机器永不触碰。
    machine_cleanup_enabled: bool = True
    machine_cleanup_interval_seconds: int = 900      # 清理扫描间隔（秒）
    machine_idle_delete_minutes: int = 5              # 池闲置自动删除阈值（最小 5）

    default_instruction: str = Field(
        default=(
            "You are a helpful conversational partner. Stay in character. "
            "Reply naturally. Do not call tools or ask structured approval questions."
        )
    )

    @property
    def session_db_path(self) -> Path:
        path = Path(self.session_db)
        if not path.is_absolute():
            path = ROOT_DIR / path
        return path

    @property
    def api_base(self) -> str:
        return self.omnara_api.rstrip("/")

    @property
    def allowed_origins(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
