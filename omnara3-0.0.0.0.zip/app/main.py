from __future__ import annotations

import asyncio
import logging
import secrets
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app import __version__
from app.bridge import Bridge
from app.config import Settings, get_settings
from app.messages import session_fingerprint
from app.omnara import (
    AccountSnapshot,
    OmnaraClient,
    OmnaraError,
    ResolvedModel,
    TokenPool,
    inspect_account,
    pinned_token,
)
from app.openai_fmt import openai_error
from app.sessions import SessionStore


class AppState:
    settings: Settings
    client: OmnaraClient
    store: SessionStore
    account: AccountSnapshot
    bridge: Bridge
    token_pool: TokenPool
    accounts: dict[str, AccountSnapshot]
    cleanup_task: "asyncio.Task[None] | None" = None


state = AppState()


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings = get_settings()
    token = settings.omnara_token.strip()
    if not token:
        raise RuntimeError(
            "未配置 OMNARA_TOKEN。复制 .env.example 为 .env，"
            "填入 app.omnara.com → API Tokens 里签发的 Token。"
        )
    if settings.require_gateway_api_key and not settings.gateway_api_key.strip():
        raise RuntimeError("生产环境必须配置 GATEWAY_API_KEY，不能让网关 API 裸奔。")
    if settings.max_request_bytes < 1024:
        raise RuntimeError("MAX_REQUEST_BYTES 不能小于 1024。")

    token_pool = TokenPool(token)
    import logging
    logging.getLogger("omnara").info(
        "[token-pool] 初始化完成，共 %d 个 Token", token_pool.count,
    )
    client = OmnaraClient(settings.api_base, token_pool, timeout=settings.turn_timeout_seconds)
    store = SessionStore(settings.session_db_path)
    await store.setup()

    # 为每个 Token 独立探测其所属的 org/project/models（多账号 Token 池的关键）
    accounts: dict[str, AccountSnapshot] = {}
    primary_account: AccountSnapshot | None = None
    for tk in token_pool.tokens():
        try:
            with pinned_token(tk):
                acc = await inspect_account(
                    client,
                    org_id=settings.omnara_org_id.strip(),
                    project_id=settings.omnara_project_id.strip(),
                )
            accounts[tk] = acc
            if primary_account is None:
                primary_account = acc
            import logging as _log
            _log.getLogger("omnara").info(
                "[token-pool] Token %s -> org=%s project=%s",
                tk[:14] + "…", acc.org_id, acc.project_id,
            )
        except OmnaraError as exc:
            import logging as _log
            _log.getLogger("omnara").warning(
                "[token-pool] Token %s 校验失败（%s），已从池中禁用", tk[:14] + "…", exc,
            )
            token_pool.mark_bad(tk, reason=f"启动校验失败: {exc}")

    if primary_account is None:
        await client.aclose()
        raise RuntimeError("Omnara Token 校验失败: 所有 Token 均无法通过启动校验。")

    state.settings = settings
    state.client = client
    state.store = store
    state.account = primary_account
    state.token_pool = token_pool
    state.accounts = accounts
    state.bridge = Bridge(
        settings,
        client,
        store,
        org_id=primary_account.org_id,
        project_id=primary_account.project_id,
        models=primary_account.models,
        accounts=accounts,
        settings_org=settings.omnara_org_id.strip(),
        settings_project=settings.omnara_project_id.strip(),
    )
    try:
        yield
    finally:
        await client.aclose()


app = FastAPI(
    title="API",
    version=__version__,
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=get_settings().allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RequestSizeLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Any) -> Any:
        length = request.headers.get("content-length")
        if length:
            try:
                too_large = int(length) > get_settings().max_request_bytes
            except ValueError:
                too_large = True
            if too_large:
                return JSONResponse(
                    openai_error("请求体过大。"),
                    status_code=413,
                )
        return await call_next(request)


app.add_middleware(RequestSizeLimitMiddleware)


def _extract_bearer(request: Request) -> str:
    header = request.headers.get("authorization") or request.headers.get("x-api-key") or ""
    if header.lower().startswith("bearer "):
        return header[7:].strip()
    return header.strip()


def _authorize(request: Request) -> None:
    expected = state.settings.gateway_api_key.strip()
    if not expected:
        return
    supplied = _extract_bearer(request)
    if not supplied or not secrets.compare_digest(supplied, expected):
        raise GatewayAuthError("网关 API Key 不对。请把酒馆的 API Key 设成 .env 里的 GATEWAY_API_KEY。")


class GatewayAuthError(Exception):
    pass


@app.exception_handler(GatewayAuthError)
async def auth_handler(_: Request, exc: GatewayAuthError) -> JSONResponse:
    return JSONResponse(openai_error(str(exc), err_type="authentication_error"), status_code=401)


@app.exception_handler(OmnaraError)
async def omnara_handler(_: Request, exc: OmnaraError) -> JSONResponse:
    status = exc.status_code if exc.status_code in {400, 401, 403, 404, 409, 429} else 502
    err_type = "authentication_error" if status == 401 else "api_error"
    return JSONResponse(openai_error(str(exc), err_type=err_type), status_code=status)


@app.get("/")
async def root() -> dict[str, Any]:
    return {"status": "ok"}


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health")
async def health(request: Request) -> dict[str, Any]:
    _authorize(request)
    account = state.account
    return {
        "status": "ok",
        "token_pool": state.token_pool.status(),
        "token_kind": account.token_kind,
        "org_id": account.org_id,
        "project_id": account.project_id,
        "models": [
            {"provider_config": model.provider_config, "name": model.name}
            for model in account.models
        ],
    }


@app.get("/v1/models")
async def list_models(request: Request) -> dict[str, Any]:
    _authorize(request)
    models = [
        {
            "id": model.name,
            "object": "model",
            "created": 0,
            "owned_by": model.provider_config or "omnara",
        }
        for model in state.account.models
    ]
    models.insert(
        0,
        {"id": "omnara", "object": "model", "created": 0, "owned_by": "omnara"},
    )
    return {"object": "list", "data": models}


# ---------------- 机器/池费用清理 ----------------


async def _machines_for_token(token: str) -> list[dict[str, Any]]:
    """用指定 Token 查询其 org 下所有机器（BYO + 池机器）。"""
    acc = state.accounts.get(token)
    org_id = acc.org_id if acc else state.account.org_id
    with pinned_token(token):
        return await state.client.list_machines(org_id)


async def _cleanup_for_token(token: str) -> dict[str, Any]:
    """对单个 Token 执行一轮机器清理，返回动作摘要。

    策略（与 config.py 注释一致）：BYO 机器永不触碰；
    其余机器尝试 DELETE（API 对池机器可能拒绝，失败仅记录），
    真正的池机器回收靠池闲置自动删除策略（见 machine_cleanup_loop）。
    """
    acc = state.accounts.get(token)
    org_id = acc.org_id if acc else state.account.org_id
    result: dict[str, Any] = {"token": token[:14] + "…", "checked": 0, "deleted": [], "kept": []}
    try:
        machines = await _machines_for_token(token)
    except OmnaraError as exc:
        result["error"] = f"列机器失败: {exc}"
        return result
    result["checked"] = len(machines)
    for m in machines:
        mid = str(m.get("id") or "")
        if not mid:
            continue
        source = str(m.get("source") or m.get("machine_type") or "").lower()
        if "byo" in source:
            # BYO 机器永不触碰（config.py 注释铁律）
            result["kept"].append({"id": mid, "reason": "BYO 机器，永不触碰"})
            continue
        try:
            with pinned_token(token):
                ok = await state.client.delete_byo_machine(org_id, mid)
            if ok:
                result["deleted"].append(mid)
            else:
                result["kept"].append({"id": mid, "reason": "DELETE 返回 False（多为非 BYO 池机器）"})
        except OmnaraError as exc:
            result["kept"].append({"id": mid, "reason": f"删除失败: {exc}"})
    return result


async def _pools_for_token(token: str) -> dict[str, Any]:
    """用指定 Token 查询其 org 下所有 machine pool。"""
    acc = state.accounts.get(token)
    org_id = acc.org_id if acc else state.account.org_id
    with pinned_token(token):
        return await state.client.list_pools(org_id)


async def _update_pool_idle_for_token(token: str, target_minutes: int) -> list[dict[str, Any]]:
    """把该 Token 自己 org 下的所有池的闲置自动删除阈值压到 target_minutes。

    多 Token 场景下每个账号有独立的 org/pool，必须逐 Token 处理；
    只用默认账号 org 会漏掉其他所有账号（曾有此 bug）。
    """
    acc = state.accounts.get(token)
    org_id = acc.org_id if acc else state.account.org_id
    actions: list[dict[str, Any]] = []
    if target_minutes <= 0:
        return actions
    try:
        with pinned_token(token):
            pools = await state.client.list_pools(org_id)
    except OmnaraError as exc:
        log = logging.getLogger("omnara")
        log.warning("[machine-cleanup] Token %s 列池失败: %s", token[:14] + "…", exc)
        return [{"pool": "?", "error": str(exc)}]
    for p in pools:
        pid = str(p.get("id") or "")
        if not pid:
            continue
        current = p.get("delete_after_idle_minutes")
        if isinstance(current, int) and current <= target_minutes:
            continue
        try:
            with pinned_token(token):
                await state.client.update_pool_idle_policy(
                    org_id, pid, target_minutes
                )
            logging.getLogger("omnara").info(
                "[machine-cleanup] Token %s 池 %s 闲置删除阈值 %s -> %d 分钟",
                token[:14] + "…", pid, current, target_minutes,
            )
            actions.append({"pool": pid, "before": current, "after": target_minutes})
        except OmnaraError as exc:
            logging.getLogger("omnara").warning(
                "[machine-cleanup] Token %s 池 %s 策略设置失败: %s",
                token[:14] + "…", pid, exc,
            )
            actions.append({"pool": pid, "error": str(exc)})
    return actions


async def machine_cleanup_loop() -> None:
    """后台循环：把所有 Token 各自 org 的 machine pool 闲置自动删除阈值
    压到配置的最小值，并删除残留机器（BYO 永不触碰）。"""
    interval = max(60, int(state.settings.machine_cleanup_interval_seconds))
    log = logging.getLogger("omnara")
    log.info(
        "[machine-cleanup] 已启动：扫描间隔 %d 秒，池闲置自动删除阈值 %d 分钟，"
        "按 Token 遍历各自 org，BYO 永不触碰",
        state.settings.machine_cleanup_interval_seconds,
        state.settings.machine_idle_delete_minutes,
    )
    while True:
        try:
            # 1) 按 Token 删除残留机器（BYO 永不触碰）
            for tk in state.token_pool.tokens():
                summary = await _cleanup_for_token(tk)
                if summary.get("deleted") or summary.get("error"):
                    log.info("[machine-cleanup] %s -> %s", summary["token"], summary)
            # 2) 把每个 Token 自己 org 的所有池的闲置自动删除阈值压到配置值
            target = state.settings.machine_idle_delete_minutes
            for tk in state.token_pool.tokens():
                await _update_pool_idle_for_token(tk, target)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            log.exception("[machine-cleanup] 本轮清理异常，下轮继续")
        await asyncio.sleep(interval)


@app.on_event("startup")
async def start_machine_cleanup() -> None:
    if not state.settings.machine_cleanup_enabled:
        logging.getLogger("omnara").info("[machine-cleanup] 未启用（MACHINE_CLEANUP_ENABLED=false）")
        return
    state.cleanup_task = asyncio.create_task(machine_cleanup_loop())


@app.on_event("shutdown")
async def stop_machine_cleanup() -> None:
    task = state.cleanup_task
    if task:
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass


@app.get("/admin/machines")
async def admin_list_machines(request: Request) -> Any:
    """列出所有 Token 视角下的机器与池，供核对费用来源。"""
    _authorize(request)
    out: list[dict[str, Any]] = []
    for tk in state.token_pool.tokens():
        item: dict[str, Any] = {"token": tk[:14] + "…"}
        try:
            acc = state.accounts.get(tk)
            org_id = acc.org_id if acc else state.account.org_id
            with pinned_token(tk):
                item["org_id"] = org_id
                item["machines"] = await state.client.list_machines(org_id)
                item["pools"] = await state.client.list_pools(org_id)
        except OmnaraError as exc:
            item["error"] = str(exc)
        out.append(item)
    return {"status": "ok", "data": out}


@app.post("/admin/machines/cleanup")
async def admin_cleanup_now(request: Request) -> Any:
    """手动立即触发一轮清理（不等待后台循环）。"""
    _authorize(request)
    out = []
    for tk in state.token_pool.tokens():
        out.append(await _cleanup_for_token(tk))
    return {"status": "ok", "data": out}


@app.get("/admin/usage")
async def admin_usage(request: Request) -> Any:
    """汇总所有账号的模型 token 用量与官方成本。

    数据来自 Omnara /orgs/{org_id}/usage，provider_reported_usd 为
    提供商原价计费金额（与账单一致）。逐 Token 查询各自 org，按模型
    累加汇总，输出总金额与各账号明细。
    """
    _authorize(request)
    accounts_out: list[dict[str, Any]] = []
    grand_usd = 0.0
    grand_calls = 0
    by_model: dict[str, dict[str, Any]] = {}
    for tk in state.token_pool.tokens():
        item: dict[str, Any] = {"token": tk[:14] + "…"}
        acc = state.accounts.get(tk)
        if acc is None:
            item["error"] = "该 Token 未通过启动校验（无账号上下文）"
            accounts_out.append(item)
            continue
        try:
            with pinned_token(tk):
                usage = await state.client.get_usage(acc.org_id)
        except OmnaraError as exc:
            item["error"] = str(exc)
            accounts_out.append(item)
            continue
        total_usd = 0.0
        total_calls = 0
        models_out: list[dict[str, Any]] = []
        for entry in usage.get("by_model") or []:
            model_info = entry.get("model") or {}
            name = str(model_info.get("name") or "unknown")
            cost = entry.get("cost") or {}
            usd = float(cost.get("provider_reported_usd") or 0)
            calls = int(entry.get("model_calls") or 0)
            tokens = entry.get("tokens") or {}
            total_usd += usd
            total_calls += calls
            models_out.append({
                "model": name,
                "calls": calls,
                "usd": round(usd, 4),
                "input_tokens": int(tokens.get("input_tokens_total") or 0),
                "output_tokens": int(tokens.get("output_tokens_total") or 0),
            })
            agg = by_model.setdefault(name, {"model": name, "calls": 0, "usd": 0.0})
            agg["calls"] += calls
            agg["usd"] = round(agg["usd"] + usd, 4)
        item["org_id"] = acc.org_id
        item["total_usd"] = round(total_usd, 4)
        item["total_calls"] = total_calls
        item["models"] = models_out
        accounts_out.append(item)
        grand_usd += total_usd
        grand_calls += total_calls
    return {
        "status": "ok",
        "total_usd": round(grand_usd, 4),
        "total_calls": grand_calls,
        "by_model": sorted(by_model.values(), key=lambda x: -x["usd"]),
        "accounts": accounts_out,
    }


@app.post("/v1/chat/completions")
@app.post("/chat/completions")
async def chat_completions(request: Request) -> Any:
    _authorize(request)
    try:
        body = await request.json()
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(openai_error(f"JSON 解析失败: {exc}"), status_code=400)

    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        return JSONResponse(openai_error("messages 不能为空"), status_code=400)

    explicit = (
        request.headers.get("x-session-id")
        or request.headers.get("x-chat-id")
        or request.headers.get("x-omnara-session")
        or str(body.get("session_id") or body.get("chat_id") or "")
    )
    session_key = session_fingerprint(messages, explicit=explicit)
    requested_model = str(body.get("model") or "omnara")
    stream = bool(body.get("stream", True))

    if stream:
        return StreamingResponse(
            state.bridge.iter_sse(
                session_key=session_key,
                messages=messages,
                requested_model=requested_model,
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    return await state.bridge.complete_json(
        session_key=session_key,
        messages=messages,
        requested_model=requested_model,
    )
