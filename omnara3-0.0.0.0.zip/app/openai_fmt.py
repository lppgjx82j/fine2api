from __future__ import annotations

import json
import time
from typing import Any


def completion_id(prefix: str = "chatcmpl") -> str:
    return f"{prefix}-{int(time.time() * 1000)}"


def chunk(
    *,
    completion_id: str,
    model: str,
    created: int,
    delta: dict[str, Any],
    finish_reason: str | None = None,
) -> str:
    payload = {
        "id": completion_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": delta,
                "finish_reason": finish_reason,
            }
        ],
    }
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def done() -> str:
    return "data: [DONE]\n\n"


def non_stream_response(
    *,
    completion_id: str,
    model: str,
    created: int,
    content: str,
    reasoning: str = "",
    finish_reason: str = "stop",
) -> dict[str, Any]:
    message: dict[str, Any] = {"role": "assistant", "content": content}
    if reasoning:
        message["reasoning_content"] = reasoning
    return {
        "id": completion_id,
        "object": "chat.completion",
        "created": created,
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": message,
                "finish_reason": finish_reason,
            }
        ],
        "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
    }


def openai_error(message: str, *, err_type: str = "invalid_request_error") -> dict[str, Any]:
    return {"error": {"message": message, "type": err_type, "param": None, "code": None}}


def map_finish_reason(stop_reason: str) -> str:
    return {
        "end_turn": "stop",
        "max_tokens": "length",
        "refusal": "content_filter",
        "content_filter": "content_filter",
        "error": "stop",
    }.get(stop_reason, "stop")
